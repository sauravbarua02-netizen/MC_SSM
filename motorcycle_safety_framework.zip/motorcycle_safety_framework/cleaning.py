"""
cleaning.py
===========
clean_trajectory_data(): de-duplicate, sort, drop unusable points/tracks,
coerce numeric types, and record every removal in a quality log so the
Trajectory_Quality sheet in the final workbook is fully auditable.

ASSUMPTIONS (documented, not hidden):
 A1. A "point" is one (Track ID, Time [s]) row. Duplicate (Track ID, Time)
     pairs within duplicate_time_tolerance are collapsed to their mean.
 A2. Tracks with fewer than params.min_track_points points are dropped --
     too short to compute heading, speed or any SSM reliably.
 A3. Rows implying instantaneous speed above max_plausible_speed_kmh are
     treated as digitisation/tracking noise and removed (not the whole
     track) -- DataFromSky trajectory extraction occasionally produces
     single-frame jumps when a track ID is briefly re-assigned.
 A4. x/y coordinates are assumed to already be in the same real-world
     metric unit across all sheets (typically meters, per DataFromSky
     ortho-rectified output). No coordinate transform is attempted here.
"""

import numpy as np
import pandas as pd
from typing import Dict
from config import Params


def _to_numeric(df: pd.DataFrame, cols) -> pd.DataFrame:
    for c in cols:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    return df


def clean_trajectory_data(sheets: Dict[str, pd.DataFrame], params: Params,
                           quality_log: list) -> Dict[str, pd.DataFrame]:
    numeric_cols = ["entry_time", "exit_time", "traveled_dist", "avg_speed",
                     "x", "y", "speed", "tan_acc", "lat_acc", "time"]
    cleaned: Dict[str, pd.DataFrame] = {}

    for sheet_name, df in sheets.items():
        n0 = len(df)
        df = df.copy()
        df = _to_numeric(df, numeric_cols)

        # Track ID must be usable as a key
        df = df.dropna(subset=["track_id", "time", "x", "y"])
        n1 = len(df)

        # normalize type field
        if "type" in df.columns:
            df["type"] = df["type"].astype(str).str.strip()
        else:
            df["type"] = "Unknown"

        df["track_id"] = df["track_id"].astype(str).str.strip()

        # collapse near-duplicate (track_id, time) rows
        # Only genuinely numeric columns are averaged; everything else
        # (type, gate labels which may be strings like "Entry Gate R",
        # __sheet__, or any other text/categorical column) takes the first
        # value in the group instead, since pandas .mean() cannot -- and
        # should not -- average strings.
        df = df.sort_values(["track_id", "time"])
        df["_time_round"] = (df["time"] / params.duplicate_time_tolerance).round()
        agg_map = {}
        for c in df.columns:
            if c in ("track_id", "_time_round"):
                continue
            if pd.api.types.is_numeric_dtype(df[c]):
                agg_map[c] = "mean"
            else:
                agg_map[c] = "first"
        df = df.groupby(["track_id", "_time_round"], as_index=False).agg(agg_map)
        df = df.drop(columns=["_time_round"], errors="ignore")
        n2 = len(df)

        # remove exact duplicate rows
        df = df.drop_duplicates(subset=["track_id", "time"])
        df = df.sort_values(["track_id", "time"]).reset_index(drop=True)

        # drop implausible-speed points (frame-level noise), not whole tracks
        removed_speed = 0
        if "speed" in df.columns:
            bad = df["speed"] > params.max_plausible_speed_kmh
            removed_speed = int(bad.sum())
            df = df.loc[~bad].copy()

        # drop short tracks
        counts = df.groupby("track_id")["time"].transform("count")
        short_tracks = df.loc[counts < params.min_track_points, "track_id"].unique()
        df = df.loc[counts >= params.min_track_points].copy()

        n_final = len(df)
        quality_log.append(
            f"[{sheet_name}] rows: raw={n0} -> after NA-drop={n1} -> "
            f"after dedup={n2} -> after implausible-speed removal "
            f"(-{removed_speed}) & short-track removal "
            f"(-{len(short_tracks)} tracks) -> final={n_final}")

        if n_final == 0:
            quality_log.append(f"[{sheet_name}] WARNING: no rows survive "
                                f"cleaning; sheet excluded from analysis")
            continue

        cleaned[sheet_name] = df

    return cleaned

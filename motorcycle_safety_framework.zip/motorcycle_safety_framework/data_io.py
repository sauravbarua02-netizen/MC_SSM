"""
data_io.py
==========
load_data(): reads every worksheet of the DataFromSky workbook and returns a
dict {sheet_name: DataFrame}, with column names normalized to a canonical
schema via config.column_aliases. No numeric processing happens here -- this
module's only job is "get everything into memory with the right column
names, preserving sheet identity".
"""

import re
import pandas as pd
import numpy as np
from typing import Dict
from config import Params


def _normalize(name: str) -> str:
    """Lower-case, strip units/punctuation, collapse whitespace."""
    if name is None:
        return ""
    s = str(name).lower()
    s = re.sub(r"\[.*?\]", " ", s)          # drop bracketed units e.g. [m/s2]
    s = re.sub(r"[^a-z0-9]+", " ", s)       # punctuation -> space
    s = re.sub(r"\s+", " ", s).strip()
    return s


def _build_reverse_alias_map(params: Params) -> Dict[str, str]:
    rev = {}
    for canonical, variants in params.column_aliases.items():
        for v in variants:
            rev[_normalize(v)] = canonical
    return rev


def map_columns(df: pd.DataFrame, params: Params, sheet_name: str,
                 quality_log: list) -> pd.DataFrame:
    """Rename df's columns to canonical names where a known alias matches.
    Unmatched columns are kept as-is (preserved, not dropped) in case they
    carry useful extra info; missing canonical columns are recorded in
    quality_log and left absent (downstream code checks for presence)."""
    rev = _build_reverse_alias_map(params)
    rename_map = {}
    matched_canonical = set()
    for col in df.columns:
        key = _normalize(col)
        if key in rev:
            rename_map[col] = rev[key]
            matched_canonical.add(rev[key])
    df = df.rename(columns=rename_map)

    # de-duplicate columns that collapsed to the same canonical name
    if df.columns.duplicated().any():
        dupes = df.columns[df.columns.duplicated()].unique().tolist()
        quality_log.append(f"[{sheet_name}] duplicate columns after mapping "
                            f"collapsed: {dupes} -- kept first occurrence")
        df = df.loc[:, ~df.columns.duplicated()]

    expected = set(params.column_aliases.keys())
    missing = expected - matched_canonical
    if missing:
        quality_log.append(f"[{sheet_name}] missing expected columns: "
                            f"{sorted(missing)}")
    return df


def load_data(params: Params, quality_log: list = None) -> Dict[str, pd.DataFrame]:
    """Read every sheet of the workbook. Sheets that fail to parse, or that
    contain no usable rows, are skipped with a note in quality_log rather
    than raising -- one bad sheet must not kill the whole run."""
    if quality_log is None:
        quality_log = []

    xls = pd.ExcelFile(params.input_path)
    sheets: Dict[str, pd.DataFrame] = {}

    for sheet_name in xls.sheet_names:
        try:
            df = xls.parse(sheet_name)
        except Exception as e:
            quality_log.append(f"[{sheet_name}] FAILED TO READ: {e}")
            continue

        if df is None or df.empty:
            quality_log.append(f"[{sheet_name}] empty sheet, skipped")
            continue

        df = df.dropna(axis=1, how="all")
        df = map_columns(df, params, sheet_name, quality_log)

        # A sheet with no track_id / time cannot be used for trajectory
        # analysis at all -- record and skip, don't silently corrupt results.
        if "track_id" not in df.columns or "time" not in df.columns:
            quality_log.append(
                f"[{sheet_name}] SKIPPED: lacks a recognizable Track ID "
                f"and/or Time column after alias mapping")
            continue

        df["__sheet__"] = sheet_name
        sheets[sheet_name] = df

    if not sheets:
        raise ValueError(
            "No usable sheets found. Check config.column_aliases against "
            "the actual column headers in the workbook.")

    quality_log.append(f"Loaded {len(sheets)} usable sheet(s): "
                        f"{list(sheets.keys())}")
    return sheets

"""
roc_analysis.py
================
perform_roc_analysis(): SI Method 5. If (and only if) a manually labelled
event file is supplied (config.manual_label_path, or later added by the
user via the Manual_Validation sheet and re-run), computes ROC curves,
AUC, sensitivity, specificity and Youden's J for each SI method against the
binary label (conflict / non-conflict), and reports the empirically
optimal SI threshold (Youden's J maximizer) PER METHOD.

If no labels are available, this module returns an explanatory placeholder
result rather than fabricating a threshold -- per the requirement to never
invent thresholds.

The manual label file is expected to have at minimum: Event_ID and a binary
or {0,1}-mappable label column (any of: Final_Manual_Label,
Manual_Label_Reviewer1, label, conflict). This module is intentionally
decoupled from the trajectory-processing pipeline: it can be re-run purely
by re-loading the label file and rejoining to the already-computed event
table.
"""

import numpy as np
import pandas as pd
from sklearn.metrics import roc_curve, roc_auc_score
from config import Params

SI_METHOD_COLS = ["SI_method1", "SI_method2", "SI_method3", "SI_method4"]


def load_manual_labels(path: str) -> pd.DataFrame:
    if not path:
        return pd.DataFrame()
    if path.lower().endswith((".xlsx", ".xls")):
        df = pd.read_excel(path)
    else:
        df = pd.read_csv(path)
    label_col = None
    for cand in ["Final_Manual_Label", "final_manual_label", "label",
                 "conflict", "Manual_Label_Reviewer1"]:
        if cand in df.columns:
            label_col = cand
            break
    if label_col is None or "Event_ID" not in df.columns:
        return pd.DataFrame()
    out = df[["Event_ID", label_col]].rename(columns={label_col: "manual_label_raw"})
    out["manual_label_binary"] = out["manual_label_raw"].apply(_to_binary)
    return out.dropna(subset=["manual_label_binary"])


def _to_binary(v):
    if pd.isna(v):
        return np.nan
    s = str(v).strip().lower()
    if s in ("1", "true", "yes", "conflict", "critical", "critical interaction",
              "extreme conflict", "evasive maneuver"):
        return 1
    if s in ("0", "false", "no", "non-conflict", "normal", "stable/normal", "close interaction"):
        return 0
    try:
        return 1 if float(s) > 0 else 0
    except ValueError:
        return np.nan


def perform_roc_analysis(ev: pd.DataFrame, params: Params, quality_log: list):
    labels = load_manual_labels(params.manual_label_path)
    if labels.empty:
        quality_log.append(
            "ROC analysis (Method 5): NO manual labels supplied -- "
            "SI_method5 and ROC/AUC results are not computed. Populate "
            "the Manual_Validation sheet's Final_Manual_Label column, save "
            "as CSV/XLSX, point config.manual_label_path at it, and re-run "
            "perform_roc_analysis() alone (no need to re-run the trajectory "
            "pipeline) to obtain empirical thresholds.")
        placeholder = pd.DataFrame([{
            "method": m, "AUC": np.nan, "optimal_threshold": np.nan,
            "sensitivity_at_opt": np.nan, "specificity_at_opt": np.nan,
            "youden_J": np.nan,
            "note": "no manual labels available"
        } for m in SI_METHOD_COLS])
        return ev, placeholder, {}

    merged = ev.merge(labels, on="Event_ID", how="left")
    n_labeled = merged["manual_label_binary"].notna().sum()
    quality_log.append(f"ROC analysis (Method 5): {n_labeled} of {len(merged)} "
                        f"events have manual labels")

    results = []
    curves = {}
    for method in SI_METHOD_COLS:
        sub = merged.dropna(subset=[method, "manual_label_binary"])
        if sub["manual_label_binary"].nunique() < 2 or len(sub) < 5:
            results.append({"method": method, "AUC": np.nan, "optimal_threshold": np.nan,
                             "sensitivity_at_opt": np.nan, "specificity_at_opt": np.nan,
                             "youden_J": np.nan,
                             "note": "insufficient labeled data or single class only"})
            continue
        y = sub["manual_label_binary"].astype(int).to_numpy()
        score = sub[method].to_numpy()
        fpr, tpr, thr = roc_curve(y, score)
        auc = roc_auc_score(y, score)
        youden = tpr - fpr
        best_i = int(np.argmax(youden))
        results.append({
            "method": method, "AUC": auc,
            "optimal_threshold": thr[best_i],
            "sensitivity_at_opt": tpr[best_i],
            "specificity_at_opt": 1 - fpr[best_i],
            "youden_J": youden[best_i],
            "note": "empirical threshold from Youden's J maximization",
        })
        curves[method] = {"fpr": fpr, "tpr": tpr, "thr": thr}

    roc_table = pd.DataFrame(results)

    # attach SI_method5 = best-performing method's score rescaled, only if
    # at least one method achieved a valid AUC
    valid = roc_table.dropna(subset=["AUC"])
    ev = ev.copy()
    if not valid.empty:
        best_method_row = valid.loc[valid["AUC"].idxmax()]
        ev["SI_method5"] = ev[best_method_row["method"]]
        ev["SI_method5_source"] = best_method_row["method"]
        ev["SI_method5_threshold"] = best_method_row["optimal_threshold"]
        quality_log.append(
            f"ROC analysis (Method 5): best-performing SI method against "
            f"manual labels is {best_method_row['method']} "
            f"(AUC={best_method_row['AUC']:.3f}); empirical threshold = "
            f"{best_method_row['optimal_threshold']:.3f}")
    else:
        ev["SI_method5"] = np.nan
        ev["SI_method5_source"] = np.nan
        ev["SI_method5_threshold"] = np.nan

    return ev, roc_table, curves

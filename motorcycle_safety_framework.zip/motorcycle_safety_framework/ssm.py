"""
ssm.py
======
calculate_ssms() and calculate_2d_features(): compute conventional and
lateral/2-D surrogate safety measures for every interaction-frame, then
collapse each pair's frames into ONE event record at the frame of closest /
most critical approach (event-level analysis, per the methodological
requirement to avoid long tracks dominating the results).

------------------------------------------------------------------
COORDINATE FRAME FOR LONGITUDINAL/LATERAL DECOMPOSITION
------------------------------------------------------------------
"Longitudinal" and "lateral" are defined relative to the SUBJECT
(motorcycle's, where applicable) heading at that instant:
    e_long = (cos(heading_subject), sin(heading_subject))     unit vector
    e_lat  = (-sin(heading_subject), cos(heading_subject))    unit vector (90 deg left)
    r = (x_interact - x_subject, y_interact - y_subject)      relative position
    C_x (longitudinal clearance) = r . e_long
    C_y (lateral clearance)      = r . e_lat
This is the standard approach for motorcycle "lane/gap filtering" studies:
it answers "how far ahead/behind and how far to the side is the other
vehicle, from the motorcycle's own point of view" -- which is what matters
for filtering/squeezing-through and swerving conflicts, rather than a
fixed global X/Y clearance that ignores the rider's orientation.

------------------------------------------------------------------
SSM DEFINITIONS AND VALIDITY CONDITIONS
------------------------------------------------------------------
Let v_rel = v_interact - v_subject (vector), and let closing speed be the
component of -v_rel along the line connecting the two vehicles (positive =
approaching).

TTC (Time-to-Collision), classic Hayward definition, valid only for
near-collinear car-following-like geometry:
    TTC = distance / closing_speed_along_line   if closing_speed_along_line > 0
    Not defined (NaN) if the vehicles are separating (closing_speed <= 0).
    We ALSO report a 2-D generalisation used for crossing/merging paths
    (see T2 and the 2D module) since motorcycle filtering/swerving
    conflicts are frequently NOT collinear, and plain Hayward TTC
    understates risk or is simply undefined in that geometry -- this
    limitation is stated explicitly in the output notes.

T2 (time to reach the point where the two paths cross), used for
crossing/merging conflicts, PET-family measure. We approximate it using
the classic "time-to-reach-crossing-point at current velocity" formulation
when both vehicles' straight-line projected paths intersect within a short
horizon; if the paths are near-parallel (no crossing solution), T2 is NaN
(explicitly not fabricated).

PET (Post-Encroachment Time): the time difference between when the subject
vehicle leaves a shared spatial zone (proxied here by the closest-approach
cell of radius max_interaction_distance_m/3) and when the interacting
vehicle arrives at that same zone. Computed at the event level (needs the
full pair trajectory, not a single frame), using the two times at which
each vehicle is closest to the identified conflict point.

DRAC (Deceleration Rate to Avoid Collision):
    DRAC = (v_subject - v_interact)^2 / (2 * distance)   [m/s^2]
    computed along the closing direction; only valid (kept) when the pair is
    closing (same validity condition as TTC) and distance > 0.

Relative speed = |v_interact - v_subject|            [m/s and km/h]
Relative lateral speed = d(C_y)/dt (finite difference of lateral clearance)
Relative acceleration = tan_acc_interact - tan_acc_subject
Lateral acceleration = lat_acc_use of the SUBJECT (already computed in
    features.py) -- reported per event as the peak absolute value in the
    approach window, since this is what signals a swerving/evasive
    maneuver.
Heading difference = wrapped angular difference between subject and
    interacting-vehicle headings at the critical frame.
Yaw/heading change = dheading_rad of the subject (already computed),
    reported as the peak absolute value in the approach window.

WHEN AN SSM CANNOT BE CALCULATED, the cell is left as NaN with a note in
SSM_notes -- values are never invented or defaulted to zero.
"""

import numpy as np
import pandas as pd
from typing import Dict
from config import Params


def _closing_speed(row) -> float:
    """Component of relative velocity along the line connecting the two
    vehicles that reduces distance (positive = approaching)."""
    dx = row["x_b"] - row["x_a"]
    dy = row["y_b"] - row["y_a"]
    dist = np.hypot(dx, dy)
    if dist == 0 or np.isnan(dist):
        return np.nan
    ux, uy = dx / dist, dy / dist  # unit vector subject -> interacting
    dvx = row["vx_b"] - row["vx_a"]
    dvy = row["vy_b"] - row["vy_a"]
    # rate of change of distance = (dv) . (unit vector) ; closing speed = -that
    d_dist_dt = dvx * ux + dvy * uy
    return -d_dist_dt


def calculate_2d_features(pairs: pd.DataFrame, params: Params) -> pd.DataFrame:
    """Frame-level longitudinal/lateral decomposition relative to subject
    heading, plus 2-D clearance measures. Adds columns in place (returns a
    new df)."""
    if pairs.empty:
        return pairs
    df = pairs.copy()

    heading = df["heading_rad_a"]
    e_long_x, e_long_y = np.cos(heading), np.sin(heading)
    e_lat_x, e_lat_y = -np.sin(heading), np.cos(heading)

    rx = df["x_b"] - df["x_a"]
    ry = df["y_b"] - df["y_a"]

    df["C_x"] = rx * e_long_x + ry * e_long_y      # longitudinal clearance [m]
    df["C_y"] = rx * e_lat_x + ry * e_lat_y        # lateral clearance [m]
    df["C_2d"] = np.hypot(df["C_x"], df["C_y"])    # Euclidean 2-D clearance [m]

    # normalized 2-D clearance: scaled by the interaction gate distance so
    # 0 = touching, 1 = at the edge of the proximity gate. This gives an
    # interpretable, bounded [0,1]-ish measure for the SI methods.
    df["C_2d_norm"] = (df["C_2d"] / params.max_interaction_distance_m).clip(lower=0)

    df["rel_speed_mps"] = np.hypot(df["vx_b"] - df["vx_a"], df["vy_b"] - df["vy_a"])
    df["rel_acc_mps2"] = df.get("tan_acc_use_b", np.nan) - df.get("tan_acc_use_a", np.nan)
    df["heading_diff_rad"] = (df["heading_rad_b"] - df["heading_rad_a"] + np.pi) % (2 * np.pi) - np.pi

    return df


def _lateral_closing_rate(g: pd.DataFrame) -> pd.Series:
    """Finite-difference derivative of C_y over time within one pair's
    frame sequence -- the rate at which lateral gap is closing (m/s);
    negative = gap shrinking on that side."""
    g = g.sort_values("time")
    dCy = g["C_y"].diff()
    dt = g["time"].diff()
    with np.errstate(divide="ignore", invalid="ignore"):
        rate = dCy / dt
    return rate


def calculate_ssms(pairs2d: pd.DataFrame, params: Params, quality_log: list) -> pd.DataFrame:
    """Collapse each Event_ID's frame sequence to one event-level record at
    the frame of minimum 2-D clearance (closest approach), computing TTC,
    T2, PET, DRAC and related measures around that frame. This is the
    EVENT-LEVEL table used for all subsequent SI / clustering / EVT work,
    so a long trajectory with thousands of frames contributes exactly ONE
    row per interacting pair, not one row per frame."""
    if pairs2d.empty:
        return pd.DataFrame()

    events = []
    for event_id, g in pairs2d.groupby("Event_ID"):
        g = g.sort_values("time").reset_index(drop=True)
        g["lat_closing_rate"] = _lateral_closing_rate(g)

        i_min = g["C_2d"].idxmin()
        crit = g.loc[i_min]

        # ---- TTC (Hayward-style, collinear approximation) ----
        closing = _closing_speed({
            "x_a": crit["x_a"], "y_a": crit["y_a"],
            "x_b": crit["x_b"], "y_b": crit["y_b"],
            "vx_a": crit["vx_a"], "vy_a": crit["vy_a"],
            "vx_b": crit["vx_b"], "vy_b": crit["vy_b"],
        })
        dist_crit = crit["C_2d"]
        ttc = np.nan
        ttc_note = ""
        if params.ttc_require_closing:
            if pd.notna(closing) and closing > 0 and dist_crit > 0:
                ttc = dist_crit / closing
                if ttc > params.ttc_max_valid_s:
                    ttc_note = f"TTC={ttc:.1f}s exceeds validity horizon ({params.ttc_max_valid_s}s); reported but not a near-miss"
            else:
                ttc_note = "not defined: vehicles not on a closing trajectory at closest-approach frame"
        else:
            if dist_crit > 0 and pd.notna(closing) and closing != 0:
                ttc = dist_crit / closing if closing > 0 else np.nan

        # ---- DRAC ----
        drac = np.nan
        if pd.notna(closing) and closing > 0 and dist_crit > 0:
            drac = (closing ** 2) / (2 * dist_crit)

        # ---- T2 (crossing-path time-to-reach-conflict-point) ----
        # Solve for intersection of the two vehicles' instantaneous velocity
        # rays from their positions at the critical frame. If rays are
        # (near-)parallel, no unique intersection exists -> NaN.
        t2 = np.nan
        t2_note = ""
        pa = np.array([crit["x_a"], crit["y_a"]])
        va = np.array([crit["vx_a"], crit["vy_a"]])
        pb = np.array([crit["x_b"], crit["y_b"]])
        vb = np.array([crit["vx_b"], crit["vy_b"]])
        denom = va[0] * (-vb[1]) - va[1] * (-vb[0])
        if abs(denom) > 1e-6 and np.all(np.isfinite(va)) and np.all(np.isfinite(vb)):
            # solve pa + t_a*va = pb + t_b*vb
            rhs = pb - pa
            t_a = (rhs[0] * (-vb[1]) - rhs[1] * (-vb[0])) / denom
            t_b = (va[0] * rhs[1] - va[1] * rhs[0]) / denom
            if t_a > 0 and t_b > 0:
                t2 = max(t_a, t_b)  # time until the LATER of the two arrives at the crossing point
            else:
                t2_note = "projected paths cross behind at least one vehicle's current position"
        else:
            t2_note = "paths near-parallel: no valid crossing point"

        # ---- PET ----
        # Conflict point proxied by the closest-approach location; find the
        # time each vehicle is nearest to that point, PET = |t_arrival_b - t_arrival_a|
        conflict_pt = np.array([(crit["x_a"] + crit["x_b"]) / 2,
                                 (crit["y_a"] + crit["y_b"]) / 2])
        d_a = np.hypot(g["x_a"] - conflict_pt[0], g["y_a"] - conflict_pt[1])
        d_b = np.hypot(g["x_b"] - conflict_pt[0], g["y_b"] - conflict_pt[1])
        t_arr_a = g.loc[d_a.idxmin(), "time"]
        t_arr_b = g.loc[d_b.idxmin(), "time"]
        pet = abs(t_arr_b - t_arr_a)
        pet_note = ""
        if pet > params.pet_max_valid_s:
            pet_note = f"PET={pet:.1f}s exceeds validity horizon; vehicles did not closely share the zone in time"
        if d_a.min() > params.max_interaction_distance_m / 2 or d_b.min() > params.max_interaction_distance_m / 2:
            pet = np.nan
            pet_note = "not reliably defined: neither vehicle closely occupies the proxy conflict point"

        # ---- lateral/longitudinal severity summary over approach window ----
        peak_lat_acc = g["lat_acc_use_a"].abs().max() if "lat_acc_use_a" in g.columns else np.nan
        peak_yaw_change = g["dheading_rad_a"].abs().max() if "dheading_rad_a" in g.columns else np.nan
        min_lat_closing_rate = g["lat_closing_rate"].min()  # most negative = fastest lateral closing

        events.append({
            "Event_ID": event_id,
            "sheet": crit["sheet"],
            "track_id_subject": crit["track_id_subject"],
            "track_id_interact": crit["track_id_interact"],
            "type_subject": crit["type_subject"],
            "type_interact": crit["type_interact"],
            "event_time_s": crit["time"],
            "n_frames_in_pair": len(g),
            "distance_m": dist_crit,
            "closing_speed_mps": closing,
            "TTC_s": ttc,
            "TTC_note": ttc_note,
            "T2_s": t2,
            "T2_note": t2_note,
            "PET_s": pet,
            "PET_note": pet_note,
            "DRAC_mps2": drac,
            "C_x_m": crit["C_x"],
            "C_y_m": crit["C_y"],
            "C_2d_m": crit["C_2d"],
            "C_2d_norm": crit["C_2d_norm"],
            "rel_speed_mps": crit["rel_speed_mps"],
            "rel_speed_kmh": crit["rel_speed_mps"] * 3.6,
            "lateral_closing_rate_mps": min_lat_closing_rate,
            "rel_acc_mps2": crit["rel_acc_mps2"],
            "peak_lateral_acc_mps2": peak_lat_acc,
            "peak_yaw_change_rad": peak_yaw_change,
            "heading_diff_rad": crit["heading_diff_rad"],
            "x_subject": crit["x_a"], "y_subject": crit["y_a"],
            "x_interact": crit["x_b"], "y_interact": crit["y_b"],
        })

    ev = pd.DataFrame(events)
    quality_log.append(f"calculate_ssms: collapsed frame-level interactions into "
                        f"{len(ev)} event-level records (one per interacting pair, "
                        f"at closest-approach frame)")

    # illustrative (NOT data-fitted) conflict flags for descriptive use only
    ev["illustrative_TTC_conflict"] = (ev["TTC_s"] <= params.illustrative_ttc_conflict_s)
    ev["illustrative_PET_conflict"] = (ev["PET_s"] <= params.illustrative_pet_conflict_s)

    return ev

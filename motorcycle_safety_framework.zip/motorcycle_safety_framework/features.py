"""
features.py
===========
calculate_trajectory_features(): per-track kinematic features needed by every
downstream SSM: sampling interval, smoothed position, velocity components,
heading angle, heading change (yaw) rate, and speed/acceleration recomputed
from positions where the raw Speed/Acc columns are missing.

EQUATIONS (documented):
  dt_i        = t_i - t_{i-1}
  vx_i        = (x_i - x_{i-1}) / dt_i         [m/s]
  vy_i        = (y_i - y_{i-1}) / dt_i         [m/s]
  heading_i   = atan2(vy_i, vx_i)              [rad], wrapped to (-pi, pi]
  dheading_i  = wrap(heading_i - heading_{i-1})       -- yaw change per step
  yaw_rate_i  = dheading_i / dt_i              [rad/s]
  speed_calc_i (km/h) = 3.6 * sqrt(vx_i^2 + vy_i^2)   -- used only if the
                        Speed [km/h] column is absent, as a fallback
  tan_acc_calc_i = (speed_calc_i_mps - speed_calc_{i-1}_mps)/dt_i  [m/s^2]
  lat_acc_calc_i = v_i * yaw_rate_i             [m/s^2]  (v * dtheta/dt,
                        standard curvilinear-motion approximation of
                        centripetal/lateral acceleration)

Where the raw DataFromSky Speed/Tan. Acc./Lat. Acc. columns exist, they are
PREFERRED over the recomputed ones (DataFromSky already differentiates the
raw pixel trajectory with its own internal filter, which is usually cleaner
than a second-order finite difference on already-quantized coordinates).
The recomputed columns are still produced and reported (suffixed _calc) so
users can compare/validate, and are used as a FALLBACK when raw fields are
missing.

SMOOTHING: a centered rolling median of width config.smoothing_window is
applied to x, y ONLY (config.apply_smoothing_to) before differentiating,
to suppress single-frame digitisation jitter without erasing genuine abrupt
swerves (a median filter preserves step-like direction changes far better
than a moving average / low-pass filter would).
"""

import numpy as np
import pandas as pd
from typing import Dict
from config import Params


def _wrap_angle(a):
    return (a + np.pi) % (2 * np.pi) - np.pi


def _process_track(g: pd.DataFrame, params: Params) -> pd.DataFrame:
    g = g.sort_values("time").reset_index(drop=True)

    # smoothing (median filter), edge-safe
    w = params.smoothing_window
    for col in params.apply_smoothing_to:
        if col in g.columns and w and w > 1:
            g[f"{col}_smooth"] = g[col].rolling(window=w, center=True,
                                                 min_periods=1).median()
        elif col in g.columns:
            g[f"{col}_smooth"] = g[col]

    x = g.get("x_smooth", g["x"]).to_numpy()
    y = g.get("y_smooth", g["y"]).to_numpy()
    t = g["time"].to_numpy()

    dt = np.diff(t, prepend=t[0] if len(t) else np.nan)
    dt[0] = np.nan  # no interval before the first point
    g["dt"] = dt

    dx = np.diff(x, prepend=x[0] if len(x) else np.nan)
    dy = np.diff(y, prepend=y[0] if len(y) else np.nan)
    with np.errstate(divide="ignore", invalid="ignore"):
        vx = dx / dt
        vy = dy / dt
    g["vx"] = vx
    g["vy"] = vy

    heading = np.arctan2(vy, vx)
    g["heading_rad"] = heading
    dheading = _wrap_angle(np.diff(heading, prepend=heading[0] if len(heading) else np.nan))
    dheading[0] = np.nan
    g["dheading_rad"] = dheading
    with np.errstate(divide="ignore", invalid="ignore"):
        g["yaw_rate_rad_s"] = dheading / dt

    speed_calc_mps = np.sqrt(vx**2 + vy**2)
    g["speed_calc_kmh"] = speed_calc_mps * 3.6

    d_speed_mps = np.diff(speed_calc_mps, prepend=speed_calc_mps[0] if len(speed_calc_mps) else np.nan)
    with np.errstate(divide="ignore", invalid="ignore"):
        g["tan_acc_calc"] = d_speed_mps / dt
        g["lat_acc_calc"] = speed_calc_mps * g["yaw_rate_rad_s"]

    # Preferred (raw-if-available) kinematics used everywhere downstream
    g["speed_use_kmh"] = g["speed"] if "speed" in g.columns else np.nan
    g["speed_use_kmh"] = g["speed_use_kmh"].fillna(g["speed_calc_kmh"]) if "speed" in g.columns else g["speed_calc_kmh"]

    g["tan_acc_use"] = g["tan_acc"] if "tan_acc" in g.columns else np.nan
    g["tan_acc_use"] = g["tan_acc_use"].fillna(g["tan_acc_calc"]) if "tan_acc" in g.columns else g["tan_acc_calc"]

    g["lat_acc_use"] = g["lat_acc"] if "lat_acc" in g.columns else np.nan
    g["lat_acc_use"] = g["lat_acc_use"].fillna(g["lat_acc_calc"]) if "lat_acc" in g.columns else g["lat_acc_calc"]

    return g


def calculate_trajectory_features(sheets: Dict[str, pd.DataFrame], params: Params,
                                   quality_log: list) -> Dict[str, pd.DataFrame]:
    out = {}
    for sheet_name, df in sheets.items():
        pieces = []
        for tid, g in df.groupby("track_id"):
            pieces.append(_process_track(g, params))
        result = pd.concat(pieces, ignore_index=True)

        # sampling interval diagnostics
        dt_valid = result["dt"].dropna()
        if len(dt_valid):
            quality_log.append(
                f"[{sheet_name}] sampling interval dt: median={dt_valid.median():.4f}s, "
                f"min={dt_valid.min():.4f}s, max={dt_valid.max():.4f}s "
                f"(n={len(dt_valid)}) -- irregular dt is handled per-step, "
                f"not assumed constant")
        out[sheet_name] = result
    return out

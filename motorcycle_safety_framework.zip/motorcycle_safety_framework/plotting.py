"""
plotting.py
===========
generate_plots(): saves every required diagnostic/analytical plot as PNG
into params.plots_dir. Every function is defensive against empty/NaN-only
inputs (writes a "no data" placeholder plot rather than crashing the whole
export, since one bad sheet should not prevent every other plot).
"""

import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats as spstats
from sklearn.metrics import roc_curve
from config import Params

plt.rcParams.update({"font.size": 10, "figure.dpi": 130})


def _empty_plot(path, title):
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.text(0.5, 0.5, "No data available", ha="center", va="center")
    ax.set_title(title)
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)


def _hist(series, path, title, xlabel, illustrative_line=None, illustrative_label=""):
    s = pd.Series(series).replace([np.inf, -np.inf], np.nan).dropna()
    if s.empty:
        _empty_plot(path, title); return
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.hist(s, bins=min(30, max(5, int(len(s) ** 0.5) * 2)), color="#3B6EA5", edgecolor="white")
    if illustrative_line is not None:
        ax.axvline(illustrative_line, color="red", linestyle="--", label=illustrative_label)
        ax.legend()
    ax.set_title(title); ax.set_xlabel(xlabel); ax.set_ylabel("Count")
    fig.savefig(path, bbox_inches="tight"); plt.close(fig)


def generate_plots(ev: pd.DataFrame, cluster_summary: pd.DataFrame,
                    roc_curves: dict, pot_result: dict, quality_log: list,
                    params: Params):
    os.makedirs(params.plots_dir, exist_ok=True)
    p = lambda name: os.path.join(params.plots_dir, name)

    if ev is None or ev.empty:
        quality_log.append("generate_plots: no event data -- placeholder plots only")
        for name, title in [("ttc_distribution.png", "TTC Distribution"),
                             ("pet_distribution.png", "PET Distribution")]:
            _empty_plot(p(name), title)
        return

    _hist(ev["TTC_s"], p("ttc_distribution.png"), "TTC Distribution", "TTC (s)",
          params.illustrative_ttc_conflict_s, "illustrative conflict TTC")
    _hist(ev["PET_s"], p("pet_distribution.png"), "PET Distribution", "PET (s)",
          params.illustrative_pet_conflict_s, "illustrative conflict PET")
    _hist(ev["C_y_m"].abs(), p("lateral_clearance_distribution.png"),
          "Lateral Clearance Distribution", "|C_y| (m)")
    _hist(ev["C_2d_m"], p("clearance_2d_distribution.png"),
          "2-D Clearance Distribution", "C_2d (m)")

    # SI distributions
    fig, axes = plt.subplots(2, 3, figsize=(15, 8))
    si_cols = ["SI_method1", "SI_method2", "SI_method3", "SI_method4", "SI_method5"]
    for ax, col in zip(axes.flat, si_cols):
        s = ev[col].dropna() if col in ev.columns else pd.Series(dtype=float)
        if s.empty:
            ax.text(0.5, 0.5, "No data", ha="center", va="center")
        else:
            ax.hist(s, bins=20, color="#5B8C5A", edgecolor="white")
        ax.set_title(col)
    for ax in axes.flat[len(si_cols):]:
        ax.axis("off")
    fig.suptitle("Safety Index Distributions (Methods 1-5)")
    fig.tight_layout()
    fig.savefig(p("si_distributions_all_methods.png"), bbox_inches="tight")
    plt.close(fig)

    # SI vs lateral clearance / TTC / T2
    for si_col in ["SI_method1", "SI_method3"]:
        if si_col not in ev.columns:
            continue
        sub = ev[[si_col, "C_y_m"]].dropna()
        fig, ax = plt.subplots(figsize=(6, 4))
        if sub.empty:
            ax.text(0.5, 0.5, "No data", ha="center", va="center")
        else:
            ax.scatter(sub["C_y_m"].abs(), sub[si_col], s=18, alpha=0.6, color="#A5573B")
        ax.set_xlabel("|Lateral clearance C_y| (m)"); ax.set_ylabel(si_col)
        ax.set_title(f"{si_col} vs Lateral Clearance")
        fig.savefig(p(f"{si_col}_vs_lateral_clearance.png"), bbox_inches="tight")
        plt.close(fig)

        sub2 = ev[[si_col, "TTC_s"]].dropna()
        fig, ax = plt.subplots(figsize=(6, 4))
        if sub2.empty:
            ax.text(0.5, 0.5, "No data", ha="center", va="center")
        else:
            ax.scatter(sub2["TTC_s"], sub2[si_col], s=18, alpha=0.6, color="#3B6EA5")
        ax.set_xlabel("TTC (s)"); ax.set_ylabel(si_col)
        ax.set_title(f"{si_col} vs TTC")
        fig.savefig(p(f"{si_col}_vs_ttc.png"), bbox_inches="tight")
        plt.close(fig)

    # interaction heatmap (spatial density of critical-approach points)
    fig, ax = plt.subplots(figsize=(6, 6))
    if ev[["x_subject", "y_subject"]].dropna().empty:
        ax.text(0.5, 0.5, "No data", ha="center", va="center")
    else:
        hb = ax.hexbin(ev["x_subject"], ev["y_subject"], gridsize=25, cmap="inferno")
        fig.colorbar(hb, ax=ax, label="Interaction count")
    ax.set_title("Spatial Heatmap of Interaction Locations")
    ax.set_xlabel("x (m)"); ax.set_ylabel("y (m)")
    fig.savefig(p("interaction_heatmap.png"), bbox_inches="tight")
    plt.close(fig)

    # clustering visualization
    fig, ax = plt.subplots(figsize=(6, 5))
    if "SI_method4_cluster_kmeans" in ev.columns and ev["SI_method4_cluster_kmeans"].notna().any():
        sub = ev.dropna(subset=["TTC_s", "C_2d_m", "SI_method4_cluster_kmeans"])
        sc = ax.scatter(sub["C_2d_m"], sub["TTC_s"], c=sub["SI_method4_cluster_kmeans"],
                         cmap="viridis", s=25)
        fig.colorbar(sc, ax=ax, label="Cluster (0=least severe)")
    else:
        ax.text(0.5, 0.5, "No clustering results", ha="center", va="center")
    ax.set_xlabel("2-D clearance (m)"); ax.set_ylabel("TTC (s)")
    ax.set_title("Clustering Visualization (Method 4)")
    fig.savefig(p("clustering_visualization.png"), bbox_inches="tight")
    plt.close(fig)

    # ROC curves
    fig, ax = plt.subplots(figsize=(6, 6))
    if roc_curves:
        for method, d in roc_curves.items():
            ax.plot(d["fpr"], d["tpr"], label=method)
        ax.plot([0, 1], [0, 1], "k--", linewidth=1)
        ax.legend(fontsize=8)
    else:
        ax.text(0.5, 0.5, "No manual labels -- ROC not available", ha="center", va="center")
    ax.set_xlabel("False Positive Rate"); ax.set_ylabel("True Positive Rate")
    ax.set_title("ROC Curves (Method 5)")
    fig.savefig(p("roc_curves.png"), bbox_inches="tight")
    plt.close(fig)

    # POT-EVT diagnostics: mean residual life + fitted GPD density
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
    if pot_result and not pot_result.get("mrl", pd.DataFrame()).empty:
        mrl = pot_result["mrl"].dropna()
        axes[0].plot(mrl["threshold"], mrl["mean_excess"], marker="o", markersize=3)
        axes[0].set_xlabel(f"Threshold u ({pot_result['target_col']})")
        axes[0].set_ylabel("Mean excess")
        axes[0].set_title("Mean Residual Life Plot")

        if pot_result.get("chosen_percentile") is not None and not pot_result["return_levels"].empty:
            x = pot_result["raw_values"]
            u = pot_result["return_levels"].attrs["threshold_u"]
            shape = pot_result["return_levels"].attrs["shape_xi"]
            scale = pot_result["return_levels"].attrs["scale_sigma"]
            exceed = x[x > u] - u
            axes[1].hist(exceed, bins=15, density=True, color="#8B5E3B",
                         edgecolor="white", alpha=0.7, label="Exceedances")
            xs = np.linspace(0, exceed.max() * 1.1 if len(exceed) else 1, 200)
            axes[1].plot(xs, spstats.genpareto.pdf(xs, shape, loc=0, scale=scale),
                         color="black", label="Fitted GPD")
            axes[1].legend(fontsize=8)
            axes[1].set_title(f"GPD Fit (shape={shape:.3f}, scale={scale:.3f})")
        else:
            axes[1].text(0.5, 0.5, "No stable GPD fit", ha="center", va="center")
    else:
        for a in axes:
            a.text(0.5, 0.5, "No data", ha="center", va="center")
    fig.tight_layout()
    fig.savefig(p("pot_evt_diagnostics.png"), bbox_inches="tight")
    plt.close(fig)

    # threshold comparison plot: SI distributions with each method's own
    # p90 and (if present) ROC-optimal / POT threshold marked
    fig, ax = plt.subplots(figsize=(7, 4.5))
    plotted = False
    for col, color in zip(["SI_method1", "SI_method2", "SI_method3"],
                           ["#3B6EA5", "#5B8C5A", "#A5573B"]):
        if col in ev.columns and ev[col].notna().any():
            s = ev[col].dropna()
            ax.hist(s, bins=20, alpha=0.35, label=col, color=color, density=True)
            ax.axvline(s.quantile(0.90), color=color, linestyle="--", linewidth=1)
            plotted = True
    if not plotted:
        ax.text(0.5, 0.5, "No data", ha="center", va="center")
    else:
        ax.legend(fontsize=8)
    ax.set_title("Threshold Comparison (dashed = each method's own 90th pct.)")
    ax.set_xlabel("SI value"); ax.set_ylabel("Density")
    fig.savefig(p("threshold_comparison.png"), bbox_inches="tight")
    plt.close(fig)

    quality_log.append(f"generate_plots: PNG files written to {params.plots_dir}")

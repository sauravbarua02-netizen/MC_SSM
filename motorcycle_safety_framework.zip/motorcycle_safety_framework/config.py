"""
config.py
=========
Central configuration for the DataFromSky motorcycle-interaction / surrogate
safety-measure (SSM) framework.

EVERY assumption that affects a number in the output lives here, in one
place, with a comment explaining why it was chosen. Nothing below is
"discovered" from the data -- these are analyst decisions and must be
reviewed against your own site geometry / camera frame rate before trusting
the results.
"""

from dataclasses import dataclass, field
from typing import Dict, List


@dataclass
class Params:
    # ---------------------------------------------------------------
    # 1. INPUT / OUTPUT
    # ---------------------------------------------------------------
    input_path: str = "2.cross_test2_pivoted.xlsx"
    output_path: str = "2.cross_test2_safety_analysis.xlsx"
    plots_dir: str = "plots"
    manual_label_path: str = ""  # optional external CSV/XLSX of manual labels; "" = none

    # ---------------------------------------------------------------
    # 2. COLUMN NAME ALIASES
    #    DataFromSky exports are not perfectly consistent between studies
    #    (e.g. "Traveled Dist. [m]" vs "Travelled Dist. [m]", "Type" vs
    #    "Class"). We match on normalized (lower, no punctuation) names,
    #    so add any observed variant here rather than changing code.
    # ---------------------------------------------------------------
    column_aliases: Dict[str, List[str]] = field(default_factory=lambda: {
        "track_id": ["track id", "trackid", "id", "vehicle id"],
        "type": ["type", "class", "vehicle type", "veh type"],
        "entry_gate": ["entry gate"],
        "entry_time": ["entry time s", "entry time"],
        "exit_gate": ["exit gate"],
        "exit_time": ["exit time s", "exit time"],
        "traveled_dist": ["traveled dist m", "travelled dist m", "distance travelled m"],
        "avg_speed": ["avg speed kmh", "average speed kmh"],
        "x": ["x m", "x"],
        "y": ["y m", "y"],
        "speed": ["speed kmh", "speed"],
        "tan_acc": ["tan acc ms2", "tangential acceleration ms2", "tan accel ms2"],
        "lat_acc": ["lat acc ms2", "lateral acceleration ms2"],
        "time": ["time s", "time"],
    })

    # Vehicle-type strings (post lower/strip) that are treated as each class.
    # DataFromSky commonly outputs: Car, Motorcycle, Medium Vehicle, Bus,
    # Heavy Vehicle, Bicycle, Pedestrian. Extend as needed.
    motorcycle_labels: List[str] = field(default_factory=lambda: [
        "motorcycle", "motorbike", "moto", "m/c", "two-wheeler", "2w"])
    car_labels: List[str] = field(default_factory=lambda: ["car", "passenger car", "auto"])
    medium_vehicle_labels: List[str] = field(default_factory=lambda: [
        "medium vehicle", "van", "pickup", "light truck", "lgv"])
    bus_labels: List[str] = field(default_factory=lambda: ["bus", "coach"])
    heavy_vehicle_labels: List[str] = field(default_factory=lambda: [
        "heavy vehicle", "truck", "hgv"])
    non_motor_labels: List[str] = field(default_factory=lambda: [
        "pedestrian", "bicycle", "cyclist"])

    # ---------------------------------------------------------------
    # 3. TRAJECTORY CLEANING
    # ---------------------------------------------------------------
    min_track_points: int = 5          # tracks shorter than this are dropped (too little info)
    max_plausible_speed_kmh: float = 150.0   # points implying > this are flagged as GPS/tracking noise
    duplicate_time_tolerance: float = 1e-6   # timestamps closer than this treated as duplicates

    # Smoothing is applied ONLY to reduce tracking jitter, NOT to change the
    # physical event structure. A short, centered rolling median is used
    # (robust to single-frame jumps) rather than a low-pass filter, which
    # can smear out genuine sharp swerves that we specifically want to keep.
    smoothing_window: int = 3          # frames; must be odd; 1 = no smoothing
    apply_smoothing_to: List[str] = field(default_factory=lambda: ["x", "y"])

    # ---------------------------------------------------------------
    # 4. INTERACTION / CONFLICT DETECTION
    #    An "interaction" (candidate pair) requires BOTH vehicles present
    #    in the same frame (temporal overlap) AND within a proximity gate
    #    (spatial overlap). This is deliberately generous -- it is a screen,
    #    not a conflict classification. Conflict/critical status is decided
    #    later from the continuous SSM values, not from this gate.
    # ---------------------------------------------------------------
    max_interaction_distance_m: float = 15.0   # Euclidean gate to flag a pair as "in proximity"
    min_overlap_frames: int = 3                # minimum simultaneous frames to call it an interaction
    require_motorcycle_in_pair: bool = True    # this study is MC-centric; set False for all-pairs

    # ---------------------------------------------------------------
    # 5. SSM VALIDITY / NUMERICAL SAFEGUARDS
    # ---------------------------------------------------------------
    ttc_max_valid_s: float = 15.0      # TTC above this is not meaningful as a "conflict" TTC -> reported but flagged
    ttc_require_closing: bool = True   # TTC only defined when closing speed > 0 (approaching)
    pet_max_valid_s: float = 15.0
    drac_min_valid_mps2: float = 0.0

    # ---------------------------------------------------------------
    # 6. SAFETY INDEX (SI) METHOD 1 WEIGHTS
    #    These weights are NOT arbitrary in the sense of being invented for
    #    this dataset; they follow the common surrogate-safety-literature
    #    practice of weighting temporal proximity (TTC-type) measures most
    #    heavily because they are the most validated predictors of crash
    #    outcome, with lateral/longitudinal spacing and closing speed as
    #    secondary contributors, and maneuver severity (lateral acc.) as a
    #    tertiary modifier capturing swerving/evasive behaviour that pure
    #    distance/time measures miss. Users should treat these as a
    #    TRANSPARENT ILLUSTRATIVE default and are strongly encouraged to
    #    re-derive weights from PCA loadings (Method 3) or from ROC-optimal
    #    coefficients (Method 5) once manual labels exist -- this is exactly
    #    why Methods 2-6 are provided alongside Method 1.
    # ---------------------------------------------------------------
    si_weights: Dict[str, float] = field(default_factory=lambda: {
        "temporal": 0.35,     # normalized inverse TTC/T2
        "lateral": 0.25,      # normalized inverse lateral clearance
        "longitudinal": 0.15, # normalized inverse longitudinal clearance
        "rel_speed": 0.15,    # normalized relative speed
        "severity": 0.10,     # normalized |lateral acceleration| (maneuver severity)
    })

    # ---------------------------------------------------------------
    # 7. CLUSTERING
    # ---------------------------------------------------------------
    n_clusters_kmeans: int = 3       # Stable / Close / Critical -- overridden by silhouette scan if enabled
    cluster_k_search: List[int] = field(default_factory=lambda: [2, 3, 4, 5])
    gmm_n_components: int = 3
    random_state: int = 42

    # ---------------------------------------------------------------
    # 8. POT-EVT
    # ---------------------------------------------------------------
    # POT is applied to the LOWER tail of clearance/TTC-like SSMs (small
    # values = severe) by analyzing exceedances of (-x) above a threshold,
    # equivalently the upper tail of the negated variable. Multiple
    # candidate thresholds (percentiles) are tested; the final threshold is
    # chosen by mean-residual-life stability, not guessed.
    pot_candidate_percentiles: List[float] = field(default_factory=lambda: [
        0.80, 0.85, 0.90, 0.95])
    pot_target_variable: str = "SI_method1"   # variable whose lower tail (or SSM's, see notes) is modeled

    # ---------------------------------------------------------------
    # 9. CLASSIFICATION LABELS (data-driven boundaries, see thresholds.py)
    # ---------------------------------------------------------------
    classification_labels: List[str] = field(default_factory=lambda: [
        "Stable/Normal", "Close Interaction", "Evasive Maneuver",
        "Critical Interaction", "Extreme Conflict"])

    # Illustrative (literature-informed, NOT data-fitted) TTC/PET reference
    # values used ONLY for descriptive flags in SSM_Results, clearly labeled
    # as illustrative and never used to set the final SI thresholds.
    illustrative_ttc_conflict_s: float = 1.5
    illustrative_pet_conflict_s: float = 1.5

"""
compare_methods.py
===================
compare_methods(): statistically compares SI Methods 1-5 (Method 6/POT-EVT
is a tail-estimation add-on, compared separately in its own diagnostics)
using:
  - distribution statistics (mean/median/SD/skew per method)
  - number of events flagged "critical" per method at each method's own
    90th-percentile cutoff (a common, method-agnostic reference point --
    NOT asserted as THE critical threshold, purely for cross-method
    comparability)
  - Pearson & Spearman correlation between methods
  - pairwise agreement (Cohen's kappa on the 90th-percentile binary flag)
  - ROC/AUC vs manual labels where available (pulled from roc_analysis output)
"""

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.metrics import cohen_kappa_score
from config import Params

SI_COLS_ALL = ["SI_method1", "SI_method2", "SI_method3", "SI_method4", "SI_method5"]


def compare_methods(ev: pd.DataFrame, roc_table: pd.DataFrame, quality_log: list):
    present = [c for c in SI_COLS_ALL if c in ev.columns and ev[c].notna().sum() > 0]
    if not present:
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

    # ---- distribution stats ----
    dist_rows = []
    for c in present:
        s = ev[c].dropna()
        n_critical_90 = int((s >= s.quantile(0.90)).sum()) if len(s) else 0
        dist_rows.append({
            "method": c, "n_valid": len(s), "mean": s.mean(), "median": s.median(),
            "sd": s.std(), "skewness": stats.skew(s) if len(s) > 2 else np.nan,
            "min": s.min(), "max": s.max(),
            "n_critical_at_own_p90": n_critical_90,
        })
    dist_stats = pd.DataFrame(dist_rows)

    # ---- correlation ----
    corr_pearson = ev[present].corr(method="pearson")
    corr_spearman = ev[present].corr(method="spearman")

    # ---- pairwise kappa agreement on p90 binary flags ----
    kappa_rows = []
    flags = {}
    for c in present:
        s = ev[c]
        thr = s.quantile(0.90)
        flags[c] = (s >= thr).astype(float)
        flags[c][s.isna()] = np.nan
    for i, a in enumerate(present):
        for b in present[i + 1:]:
            sub = pd.concat([flags[a], flags[b]], axis=1).dropna()
            if len(sub) < 5 or sub.iloc[:, 0].nunique() < 2 or sub.iloc[:, 1].nunique() < 2:
                kappa = np.nan
            else:
                kappa = cohen_kappa_score(sub.iloc[:, 0], sub.iloc[:, 1])
            kappa_rows.append({"method_a": a, "method_b": b, "cohen_kappa_p90_flag": kappa})
    agreement = pd.DataFrame(kappa_rows)

    combined_corr = pd.concat({"pearson": corr_pearson, "spearman": corr_spearman})

    if roc_table is not None and not roc_table.empty and roc_table["AUC"].notna().any():
        quality_log.append("compare_methods: AUC-based ranking available in "
                            "SI_Method_Comparison / ROC_Results sheets")
    quality_log.append(f"compare_methods: compared {len(present)} SI methods "
                        f"across {len(ev)} events "
                        f"({dist_stats[['method','n_valid']].to_dict('records')})")

    return dist_stats, combined_corr, agreement

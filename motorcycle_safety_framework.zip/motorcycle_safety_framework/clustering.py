"""
clustering.py
=============
perform_clustering(): SI Method 4. Uses K-means and Gaussian Mixture
clustering on standardized SSM features to identify natural groupings of
interactions (e.g. Stable / Close / Critical) WITHOUT assuming a threshold
in advance -- the cluster boundaries themselves become data-driven
candidate thresholds (reported in Thresholds sheet).

Number of clusters (k) is chosen by scanning config.cluster_k_search and
picking the k with the best silhouette score, rather than fixing k
arbitrarily -- reported alongside the fixed default for transparency.
"""

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.mixture import GaussianMixture
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score
from config import Params

CLUSTER_FEATURES = ["TTC_s", "T2_s", "C_2d_m", "rel_speed_mps",
                     "peak_lateral_acc_mps2"]


def _prep_features(ev: pd.DataFrame):
    X = ev[CLUSTER_FEATURES].copy()
    # severity orientation: invert time/clearance measures so "large = severe"
    # consistently across all clustering features (unstandardized here;
    # StandardScaler below handles scale)
    for c in ["TTC_s", "T2_s", "C_2d_m"]:
        X[c] = -X[c]
    valid_mask = X.notna().sum(axis=1) >= 3
    X_valid = X.loc[valid_mask].fillna(X.loc[valid_mask].median())
    # guard against a feature column that is entirely NaN (median also NaN)
    X_valid = X_valid.fillna(0)
    return X_valid, valid_mask


def perform_clustering(ev: pd.DataFrame, params: Params, quality_log: list):
    if ev.empty:
        return ev, pd.DataFrame()

    X_valid, valid_mask = _prep_features(ev)
    if len(X_valid) < 6:
        quality_log.append("Clustering (Method 4): fewer than 6 valid events "
                            "-- clustering skipped")
        ev = ev.copy()
        ev["SI_method4_cluster_kmeans"] = np.nan
        ev["SI_method4_cluster_gmm"] = np.nan
        ev["SI_method4"] = np.nan
        return ev, pd.DataFrame()

    scaler = StandardScaler()
    Xs = scaler.fit_transform(X_valid)

    # ---- choose k by silhouette scan ----
    sil_scores = {}
    for k in params.cluster_k_search:
        if k >= len(X_valid):
            continue
        km = KMeans(n_clusters=k, random_state=params.random_state, n_init=10).fit(Xs)
        try:
            sil_scores[k] = silhouette_score(Xs, km.labels_)
        except Exception:
            sil_scores[k] = np.nan
    best_k = max(sil_scores, key=sil_scores.get) if sil_scores else params.n_clusters_kmeans
    quality_log.append(f"Clustering (Method 4): silhouette scan over k={list(sil_scores)} "
                        f"-> best k={best_k} (silhouette={sil_scores.get(best_k, np.nan):.3f}); "
                        f"config default k={params.n_clusters_kmeans} used only if scan fails")

    k_final = best_k if sil_scores else params.n_clusters_kmeans
    km_final = KMeans(n_clusters=k_final, random_state=params.random_state, n_init=10).fit(Xs)
    gmm_final = GaussianMixture(n_components=params.gmm_n_components,
                                 random_state=params.random_state).fit(Xs)
    gmm_labels = gmm_final.predict(Xs)

    # order cluster labels by mean severity composite (mean of standardized
    # features) so label "0" = least severe, highest index = most severe --
    # avoids arbitrary k-means label numbering
    severity_score = Xs.mean(axis=1)
    km_order = pd.Series(severity_score).groupby(km_final.labels_).mean().sort_values().index.tolist()
    km_relabel = {old: new for new, old in enumerate(km_order)}
    km_labels_ordered = np.array([km_relabel[l] for l in km_final.labels_])

    gmm_order = pd.Series(severity_score).groupby(gmm_labels).mean().sort_values().index.tolist()
    gmm_relabel = {old: new for new, old in enumerate(gmm_order)}
    gmm_labels_ordered = np.array([gmm_relabel[l] for l in gmm_labels])

    ev = ev.copy()
    ev["SI_method4_cluster_kmeans"] = np.nan
    ev["SI_method4_cluster_gmm"] = np.nan
    ev.loc[valid_mask, "SI_method4_cluster_kmeans"] = km_labels_ordered
    ev.loc[valid_mask, "SI_method4_cluster_gmm"] = gmm_labels_ordered

    # SI_method4: normalized cluster rank (0..1) from k-means, so it's
    # comparable in scale to Methods 1-3
    max_label = k_final - 1 if k_final > 1 else 1
    ev["SI_method4"] = ev["SI_method4_cluster_kmeans"] / max_label

    cluster_summary_rows = []
    for label in sorted(set(km_labels_ordered)):
        idx = ev.index[ev["SI_method4_cluster_kmeans"] == label]
        row = {"cluster": label, "n_events": len(idx)}
        for feat in CLUSTER_FEATURES:
            row[f"mean_{feat}"] = ev.loc[idx, feat].mean()
        cluster_summary_rows.append(row)
    cluster_summary = pd.DataFrame(cluster_summary_rows)
    cluster_summary.attrs["k_final"] = k_final
    cluster_summary.attrs["silhouette_scores"] = sil_scores

    quality_log.append(f"Clustering (Method 4): cluster sizes (k-means, k={k_final}): "
                        f"{cluster_summary[['cluster','n_events']].to_dict('records')}")

    return ev, cluster_summary

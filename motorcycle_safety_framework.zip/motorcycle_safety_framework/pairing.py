"""
pairing.py
==========
identify_vehicle_pairs(): builds the candidate interaction table. Rather than
computing SSMs for O(n^2) vehicle pairs, we first screen pairs down to those
that are BOTH temporally overlapping (share frames) AND spatially close at
some point (Euclidean distance <= max_interaction_distance_m) for at least
min_overlap_frames consecutive/total frames. This keeps the analysis
tractable and avoids treating far-apart, non-interacting vehicles as
"interactions" just because they happen to be in the same video.

Vehicle classes (config.*_labels) are used to filter to the pairs relevant to
motorcycle safety: MC-car, MC-medium vehicle, MC-bus, MC-MC (and MC-heavy
vehicle if present). Set require_motorcycle_in_pair=False in config to widen
to all classes.

Each surviving pair gets one row per overlapping timestamp (long format) --
this "interaction-frame" table is the input to ssm.py, which then collapses
each pair down to one or more discrete Events (Event_ID) at the point(s) of
closest/most critical approach.
"""

import itertools
import numpy as np
import pandas as pd
from typing import Dict
from config import Params


def _classify_type(raw_type: str, params: Params) -> str:
    t = str(raw_type).strip().lower()
    if t in params.motorcycle_labels or "motor" in t and "vehicle" not in t:
        pass
    if any(lbl in t for lbl in params.motorcycle_labels):
        return "Motorcycle"
    if any(lbl in t for lbl in params.bus_labels):
        return "Bus"
    if any(lbl in t for lbl in params.heavy_vehicle_labels):
        return "Heavy Vehicle"
    if any(lbl in t for lbl in params.medium_vehicle_labels):
        return "Medium Vehicle"
    if any(lbl in t for lbl in params.car_labels):
        return "Car"
    if any(lbl in t for lbl in params.non_motor_labels):
        return "Non-motorized"
    return "Other/Unknown"


RELEVANT_PAIR_TYPES = {
    frozenset(["Motorcycle", "Car"]),
    frozenset(["Motorcycle", "Medium Vehicle"]),
    frozenset(["Motorcycle", "Bus"]),
    frozenset(["Motorcycle", "Heavy Vehicle"]),
    frozenset(["Motorcycle"]),  # MC-MC (same-class pair -> frozenset len 1)
}


def identify_vehicle_pairs(sheets: Dict[str, pd.DataFrame], params: Params,
                            quality_log: list) -> pd.DataFrame:
    all_pairs = []

    for sheet_name, df in sheets.items():
        df = df.copy()
        df["veh_class"] = df["type"].apply(lambda t: _classify_type(t, params))

        tracks = {tid: g.sort_values("time").reset_index(drop=True)
                  for tid, g in df.groupby("track_id")}
        track_ids = list(tracks.keys())
        n_candidate_pairs = 0
        n_kept_pairs = 0

        for tid_a, tid_b in itertools.combinations(track_ids, 2):
            ga, gb = tracks[tid_a], tracks[tid_b]
            cls_a = ga["veh_class"].iloc[0]
            cls_b = gb["veh_class"].iloc[0]

            if params.require_motorcycle_in_pair:
                if "Motorcycle" not in (cls_a, cls_b):
                    continue
            pair_key = frozenset([cls_a, cls_b]) if cls_a != cls_b else frozenset([cls_a])
            if params.require_motorcycle_in_pair and pair_key not in RELEVANT_PAIR_TYPES:
                continue

            n_candidate_pairs += 1

            # temporal overlap
            t_lo = max(ga["time"].min(), gb["time"].min())
            t_hi = min(ga["time"].max(), gb["time"].max())
            if t_hi <= t_lo:
                continue

            # merge on nearest time within overlap window (handles slightly
            # different sampling instants between two independent tracks)
            ga_ov = ga[(ga["time"] >= t_lo) & (ga["time"] <= t_hi)]
            gb_ov = gb[(gb["time"] >= t_lo) & (gb["time"] <= t_hi)]
            if ga_ov.empty or gb_ov.empty:
                continue

            merged = pd.merge_asof(
                ga_ov.sort_values("time"), gb_ov.sort_values("time"),
                on="time", direction="nearest",
                suffixes=("_a", "_b"),
                tolerance=max(ga_ov["dt"].median(skipna=True) or 0.5,
                              gb_ov["dt"].median(skipna=True) or 0.5) * 1.5)
            merged = merged.dropna(subset=["x_a", "x_b"])
            if merged.empty:
                continue

            dist = np.hypot(merged["x_a"] - merged["x_b"], merged["y_a"] - merged["y_b"])
            close = merged.loc[dist <= params.max_interaction_distance_m].copy()
            if len(close) < params.min_overlap_frames:
                continue

            close["distance_m"] = dist.loc[close.index]
            close["track_id_subject"] = tid_a
            close["track_id_interact"] = tid_b
            close["type_subject"] = cls_a
            close["type_interact"] = cls_b
            close["sheet"] = sheet_name

            # ensure "subject" is always the motorcycle when one exists, for
            # a consistent, readable Event table
            if params.require_motorcycle_in_pair and cls_b == "Motorcycle" and cls_a != "Motorcycle":
                close = close.rename(columns={
                    "track_id_subject": "track_id_interact_tmp"})
                close["track_id_subject"], close["track_id_interact"] = (
                    close["track_id_interact"], tid_a)
                close["type_subject"], close["type_interact"] = cls_b, cls_a
                # swap kinematic columns too
                swap_cols = [c for c in close.columns if c.endswith("_a") or c.endswith("_b")]
                a_cols = [c for c in swap_cols if c.endswith("_a")]
                for ca in a_cols:
                    cb = ca[:-2] + "_b"
                    if cb in close.columns:
                        close[ca], close[cb] = close[cb].copy(), close[ca].copy()
                close = close.drop(columns=["track_id_interact_tmp"], errors="ignore")

            n_kept_pairs += 1
            all_pairs.append(close)

        quality_log.append(
            f"[{sheet_name}] pair screening: {n_candidate_pairs} candidate "
            f"MC-relevant pairs -> {n_kept_pairs} pairs meeting proximity/"
            f"overlap criteria (<= {params.max_interaction_distance_m} m for "
            f">= {params.min_overlap_frames} frames)")

    if not all_pairs:
        quality_log.append("WARNING: no interacting pairs found across any sheet.")
        return pd.DataFrame()

    result = pd.concat(all_pairs, ignore_index=True)
    # unique Event_ID per (sheet, subject, interacting) pair
    result["Event_ID"] = (
        result["sheet"].astype(str) + "_" +
        result["track_id_subject"].astype(str) + "_" +
        result["track_id_interact"].astype(str))
    return result

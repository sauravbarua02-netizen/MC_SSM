"""
run_analysis.py
================
Main entry point. Orchestrates the full pipeline end-to-end:

    load_data -> clean_trajectory_data -> calculate_trajectory_features ->
    identify_vehicle_pairs -> calculate_2d_features -> calculate_ssms ->
    calculate_safety_indices -> perform_clustering -> perform_roc_analysis ->
    perform_pot_evt -> build_classification -> compare_methods ->
    generate_plots -> export_results_to_excel

USAGE
-----
    python run_analysis.py

Edit config.py (input_path, output_path, manual_label_path, any
column_aliases/thresholds) rather than editing this file.

To add manual labels LATER without re-running trajectory processing:
    1. Open the exported workbook's Manual_Validation sheet, fill in
       Final_Manual_Label (or Manual_Label_Reviewer1/2) per Event_ID from
       video review, save as manual_labels.csv (Event_ID, Final_Manual_Label).
    2. Set params.manual_label_path = "manual_labels.csv".
    3. Re-run this script -- perform_roc_analysis() and the classification
       step will pick up the labels automatically; nothing about trajectory
       processing changes.
"""

import sys
import traceback
import pandas as pd
import numpy as np

from config import Params
from data_io import load_data
from cleaning import clean_trajectory_data
from features import calculate_trajectory_features
from pairing import identify_vehicle_pairs
from ssm import calculate_2d_features, calculate_ssms
from safety_index import calculate_safety_indices
from clustering import perform_clustering
from roc_analysis import perform_roc_analysis
from pot_evt import perform_pot_evt
from thresholds import build_classification
from compare_methods import compare_methods
from plotting import generate_plots
from export_excel import export_results_to_excel


def main(params: Params = None):
    if params is None:
        params = Params()
    quality_log = []

    print("[1/13] load_data ...")
    sheets = load_data(params, quality_log)

    print("[2/13] clean_trajectory_data ...")
    sheets = clean_trajectory_data(sheets, params, quality_log)

    print("[3/13] calculate_trajectory_features ...")
    sheets = calculate_trajectory_features(sheets, params, quality_log)

    print("[4/13] identify_vehicle_pairs ...")
    pairs = identify_vehicle_pairs(sheets, params, quality_log)

    print("[5/13] calculate_2d_features ...")
    pairs2d = calculate_2d_features(pairs, params)

    print("[6/13] calculate_ssms ...")
    ev = calculate_ssms(pairs2d, params, quality_log)

    print("[7/13] calculate_safety_indices (Methods 1-3) ...")
    ev, pca_loadings, pca_explained = calculate_safety_indices(ev, params, quality_log)

    print("[8/13] perform_clustering (Method 4) ...")
    ev, cluster_summary = perform_clustering(ev, params, quality_log)

    print("[9/13] perform_roc_analysis (Method 5) ...")
    ev, roc_table, roc_curves = perform_roc_analysis(ev, params, quality_log)

    print("[10/13] perform_pot_evt (Method 6) ...")
    pot_diag, pot_result = perform_pot_evt(ev, params, quality_log)

    print("[11/13] build_classification ...")
    ev, thresholds_table = build_classification(
        ev, cluster_summary, roc_table, pot_result, params, quality_log)

    print("[12/13] compare_methods ...")
    dist_stats, corr, agreement = compare_methods(ev, roc_table, quality_log)

    print("[13/13] generate_plots + export_results_to_excel ...")
    generate_plots(ev, cluster_summary, roc_curves, pot_result, quality_log, params)

    # ---- assemble output tables ----
    summary = _build_summary(sheets, ev, params, quality_log)
    vehicle_interactions = _build_vehicle_interactions_table(pairs2d)
    ssm_results = _build_ssm_results_table(ev)
    safety_index_table = _build_safety_index_table(ev)
    manual_validation = _build_manual_validation_table(ev)
    trajectory_quality = pd.DataFrame({"log_entry": quality_log})
    parameters = _params_to_table(params)

    return_levels = pot_result.get("return_levels", pd.DataFrame()) if pot_result else pd.DataFrame()

    export_results_to_excel(
        params, quality_log,
        summary=summary,
        vehicle_interactions=vehicle_interactions,
        ssm_results=ssm_results,
        safety_index=safety_index_table,
        si_method_comparison={"dist_stats": dist_stats, "correlation": corr, "agreement": agreement},
        clustering_summary=cluster_summary,
        roc_results=roc_table,
        pot_evt_diag=pot_diag,
        pot_evt_return_levels=return_levels,
        thresholds=thresholds_table,
        manual_validation=manual_validation,
        trajectory_quality=trajectory_quality,
        parameters=parameters,
        pca_loadings=pca_loadings,
        pca_explained=pca_explained,
    )

    print("\n".join(quality_log[-10:]))
    print(f"\nDone. Workbook: {params.output_path}")
    print(f"Plots: {params.plots_dir}")
    return ev, quality_log


def _build_summary(sheets, ev, params, quality_log):
    rows = []
    rows.append({"metric": "Number of sheets processed", "value": len(sheets)})
    rows.append({"metric": "Sheet names", "value": ", ".join(sheets.keys())})
    total_tracks = sum(df["track_id"].nunique() for df in sheets.values())
    rows.append({"metric": "Total unique tracks (all sheets)", "value": total_tracks})
    for cls_key, label in [("Motorcycle", "Motorcycle tracks"), ("Car", "Car tracks")]:
        pass
    if not ev.empty:
        rows.append({"metric": "Total interaction events identified", "value": len(ev)})
        for t in sorted(ev["type_interact"].unique()):
            n = (ev["type_interact"] == t).sum()
            rows.append({"metric": f"Events: Motorcycle vs {t}", "value": int(n)})
        rows.append({"metric": "Median TTC (s), closing pairs only", "value": ev["TTC_s"].median()})
        rows.append({"metric": "Median PET (s)", "value": ev["PET_s"].median()})
        rows.append({"metric": "Median 2-D clearance (m)", "value": ev["C_2d_m"].median()})
        if "Safety_Classification" in ev.columns:
            vc = ev["Safety_Classification"].value_counts()
            for k, v in vc.items():
                rows.append({"metric": f"Events classified: {k}", "value": int(v)})
    else:
        rows.append({"metric": "Total interaction events identified", "value": 0})
        rows.append({"metric": "NOTE", "value": "No qualifying motorcycle interactions found -- "
                                                  "check max_interaction_distance_m / require_motorcycle_in_pair in config.py"})
    rows.append({"metric": "Analysis generated", "value": pd.Timestamp.now().isoformat()})
    return pd.DataFrame(rows)


def _build_vehicle_interactions_table(pairs2d):
    if pairs2d is None or pairs2d.empty:
        return pd.DataFrame(columns=["Event_ID", "sheet", "track_id_subject",
                                      "track_id_interact", "type_subject", "type_interact",
                                      "time", "distance_m", "C_x", "C_y", "C_2d"])
    cols = ["Event_ID", "sheet", "track_id_subject", "track_id_interact",
            "type_subject", "type_interact", "time", "distance_m",
            "C_x", "C_y", "C_2d", "C_2d_norm", "rel_speed_mps", "heading_diff_rad"]
    cols = [c for c in cols if c in pairs2d.columns]
    return pairs2d[cols].sort_values(["Event_ID", "time"]).reset_index(drop=True)


def _build_ssm_results_table(ev):
    if ev is None or ev.empty:
        return pd.DataFrame()
    cols = ["Event_ID", "sheet", "track_id_subject", "track_id_interact",
            "type_subject", "type_interact", "event_time_s", "n_frames_in_pair",
            "distance_m", "closing_speed_mps", "TTC_s", "TTC_note", "T2_s", "T2_note",
            "PET_s", "PET_note", "DRAC_mps2", "C_x_m", "C_y_m", "C_2d_m",
            "rel_speed_mps", "rel_speed_kmh", "lateral_closing_rate_mps",
            "rel_acc_mps2", "peak_lateral_acc_mps2", "peak_yaw_change_rad",
            "heading_diff_rad", "illustrative_TTC_conflict", "illustrative_PET_conflict"]
    cols = [c for c in cols if c in ev.columns]
    return ev[cols].reset_index(drop=True)


def _build_safety_index_table(ev):
    if ev is None or ev.empty:
        return pd.DataFrame()
    cols = ["Event_ID", "sheet", "track_id_subject", "track_id_interact",
            "type_subject", "type_interact",
            "M1_temporal_component", "M1_lateral_component", "M1_longitudinal_component",
            "M1_relspeed_component", "M1_severity_component", "SI_method1",
            "M2_temporal_component", "M2_clearance_component", "SI_method2",
            "SI_method3", "SI_method4_cluster_kmeans", "SI_method4_cluster_gmm", "SI_method4",
            "SI_method5", "SI_method5_source", "SI_method5_threshold",
            "Safety_Classification", "Classification_Basis"]
    cols = [c for c in cols if c in ev.columns]
    return ev[cols].reset_index(drop=True)


def _build_manual_validation_table(ev):
    if ev is None or ev.empty:
        cols = ["Event_ID", "sheet", "track_id_subject", "track_id_interact",
                "type_subject", "type_interact", "event_time_s", "TTC_s", "T2_s", "PET_s",
                "C_y_m", "C_x_m", "C_2d_m", "rel_speed_mps", "peak_lateral_acc_mps2",
                "SI_method1", "SI_method2", "SI_method3", "SI_method4", "SI_method5",
                "Manual_Label_Reviewer1", "Manual_Label_Reviewer2", "Final_Manual_Label",
                "Maneuver_Type", "Validation_Notes"]
        return pd.DataFrame(columns=cols)
    df = ev.copy()
    for c in ["Manual_Label_Reviewer1", "Manual_Label_Reviewer2", "Final_Manual_Label",
              "Maneuver_Type", "Validation_Notes"]:
        df[c] = ""
    cols = ["Event_ID", "sheet", "track_id_subject", "track_id_interact",
            "type_subject", "type_interact", "event_time_s", "TTC_s", "T2_s", "PET_s",
            "C_y_m", "C_x_m", "C_2d_m", "rel_speed_mps", "peak_lateral_acc_mps2",
            "SI_method1", "SI_method2", "SI_method3", "SI_method4", "SI_method5",
            "Manual_Label_Reviewer1", "Manual_Label_Reviewer2", "Final_Manual_Label",
            "Maneuver_Type", "Validation_Notes"]
    cols = [c for c in cols if c in df.columns]
    return df[cols].reset_index(drop=True)


def _params_to_table(params: Params):
    rows = []
    for k, v in params.__dict__.items():
        rows.append({"parameter": k, "value": str(v)})
    return pd.DataFrame(rows)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        sys.exit(1)

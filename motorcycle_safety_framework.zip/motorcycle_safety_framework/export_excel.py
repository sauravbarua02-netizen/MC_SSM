"""
export_excel.py
================
export_results_to_excel(): writes every result table into one workbook with
the exact sheet layout requested. Uses pandas.ExcelWriter (openpyxl engine)
for bulk data -- these are computed analysis RESULTS, not a formula-driven
template, so values are written directly (re-deriving them live in Excel
formulas is not practical for PCA/clustering/GPD outputs); each sheet's
provenance is documented in the Parameters sheet.
"""

import os
import numpy as np
import pandas as pd
from openpyxl.utils import get_column_letter
from config import Params


def _autofit(ws, df, max_width=45):
    for i, col in enumerate(df.columns, start=1):
        try:
            width = max(len(str(col)), df[col].astype(str).str.len().max() if len(df) else 0)
        except Exception:
            width = len(str(col))
        ws.column_dimensions[get_column_letter(i)].width = min(max_width, max(10, width + 2))


def _write(writer, df, sheet_name, freeze="A2"):
    if df is None:
        df = pd.DataFrame()
    df.to_excel(writer, sheet_name=sheet_name[:31], index=False)
    ws = writer.sheets[sheet_name[:31]]
    ws.freeze_panes = freeze
    _autofit(ws, df)


def export_results_to_excel(params: Params, quality_log: list, *,
                             summary: pd.DataFrame,
                             vehicle_interactions: pd.DataFrame,
                             ssm_results: pd.DataFrame,
                             safety_index: pd.DataFrame,
                             si_method_comparison: dict,
                             clustering_summary: pd.DataFrame,
                             roc_results: pd.DataFrame,
                             pot_evt_diag: pd.DataFrame,
                             pot_evt_return_levels: pd.DataFrame,
                             thresholds: pd.DataFrame,
                             manual_validation: pd.DataFrame,
                             trajectory_quality: pd.DataFrame,
                             parameters: pd.DataFrame,
                             pca_loadings: pd.DataFrame,
                             pca_explained: pd.DataFrame):
    out_dir = os.path.dirname(params.output_path)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)

    with pd.ExcelWriter(params.output_path, engine="openpyxl") as writer:
        _write(writer, summary, "Summary")
        _write(writer, vehicle_interactions, "Vehicle_Interactions")
        _write(writer, ssm_results, "SSM_Results")
        _write(writer, safety_index, "Safety_Index")

        # SI_Method_Comparison: several tables stacked with headers
        dist_stats = si_method_comparison.get("dist_stats", pd.DataFrame())
        corr = si_method_comparison.get("correlation", pd.DataFrame())
        agreement = si_method_comparison.get("agreement", pd.DataFrame())
        dist_stats.to_excel(writer, sheet_name="SI_Method_Comparison", index=False, startrow=0)
        ws = writer.sheets["SI_Method_Comparison"]
        ws.freeze_panes = "A2"
        _autofit(ws, dist_stats)
        r0 = len(dist_stats) + 3
        ws.cell(row=r0, column=1, value="Correlation matrix (Pearson & Spearman, MultiIndex rows)")
        corr_reset = corr.reset_index() if not corr.empty else corr
        if not corr_reset.empty:
            corr_reset.to_excel(writer, sheet_name="SI_Method_Comparison", index=False, startrow=r0)
        r1 = r0 + len(corr_reset) + 3 if not corr_reset.empty else r0 + 3
        ws.cell(row=r1, column=1, value="Pairwise agreement (Cohen's kappa on each method's own 90th-pct flag)")
        if not agreement.empty:
            agreement.to_excel(writer, sheet_name="SI_Method_Comparison", index=False, startrow=r1)

        _write(writer, clustering_summary, "Clustering")
        _write(writer, roc_results, "ROC_Results")

        pot_evt_diag.to_excel(writer, sheet_name="POT_EVT", index=False, startrow=0)
        ws = writer.sheets["POT_EVT"]
        ws.freeze_panes = "A2"
        _autofit(ws, pot_evt_diag)
        r0 = len(pot_evt_diag) + 3
        ws.cell(row=r0, column=1, value="Estimated extreme/rare-event levels (GPD-based, chosen threshold)")
        if not pot_evt_return_levels.empty:
            pot_evt_return_levels.to_excel(writer, sheet_name="POT_EVT", index=False, startrow=r0)

        _write(writer, thresholds, "Thresholds")
        _write(writer, manual_validation, "Manual_Validation")
        _write(writer, trajectory_quality, "Trajectory_Quality")

        # PCA loadings appended to Parameters-adjacent sheet for traceability
        parameters.to_excel(writer, sheet_name="Parameters", index=False, startrow=0)
        ws = writer.sheets["Parameters"]
        ws.freeze_panes = "A2"
        _autofit(ws, parameters)
        if not pca_loadings.empty:
            r0 = len(parameters) + 3
            ws.cell(row=r0, column=1, value="PCA (Method 3) component loadings")
            pca_loadings.reset_index().rename(columns={"index": "variable"}).to_excel(
                writer, sheet_name="Parameters", index=False, startrow=r0)
            r1 = r0 + len(pca_loadings) + 3
            ws.cell(row=r1, column=1, value="PCA explained variance")
            if not pca_explained.empty:
                pca_explained.to_excel(writer, sheet_name="Parameters", index=False, startrow=r1)

    quality_log.append(f"export_results_to_excel: workbook written to {params.output_path}")

"""
safety_index.py
===============
calculate_safety_indices(): implements SI Methods 1-3 (weighted-normalized,
distance-time, PCA). Methods 4-6 (clustering, ROC, POT-EVT) live in their own
modules (clustering.py, roc_analysis.py, pot_evt.py) since they need extra
inputs (labels, threshold scans) and produce their own diagnostic tables.

All methods operate on the EVENT-LEVEL table (one row per interacting pair),
per the requirement to prevent long trajectories from dominating results.

Normalization convention: every raw SSM is transformed to a "severity"
scale in [0, 1] where 1 = most severe / closest to conflict, using a
robust min-max scaling (1st/99th percentile clipping) computed ACROSS ALL
EVENTS in the dataset, not per-sheet -- so SI values are comparable between
sheets. NaNs (SSM not computable, e.g. non-closing pair) are excluded from
the percentile computation and left as NaN in the normalized column
(propagated as NaN in the final SI, never silently treated as "safe").
"""

import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from config import Params


def _robust_norm_inverse(s: pd.Series, low_q=0.01, high_q=0.99) -> pd.Series:
    """For measures where SMALL raw value = MORE severe (TTC, T2, PET,
    clearances): normalize to [0,1] with 1 = most severe."""
    valid = s.dropna()
    if valid.empty:
        return pd.Series(np.nan, index=s.index)
    lo, hi = valid.quantile(low_q), valid.quantile(high_q)
    if hi <= lo:
        hi = valid.max(); lo = valid.min()
    if hi <= lo:
        return pd.Series(0.5, index=s.index).where(s.notna())
    clipped = s.clip(lower=lo, upper=hi)
    norm = (clipped - lo) / (hi - lo)     # 0=far/safe(large value), 1=close/severe... wait invert
    return (1 - norm).where(s.notna())


def _robust_norm_direct(s: pd.Series, low_q=0.01, high_q=0.99) -> pd.Series:
    """For measures where LARGE raw value = MORE severe (relative speed,
    |lateral acceleration|, DRAC): normalize to [0,1] with 1 = most severe."""
    valid = s.dropna()
    if valid.empty:
        return pd.Series(np.nan, index=s.index)
    lo, hi = valid.quantile(low_q), valid.quantile(high_q)
    if hi <= lo:
        hi = valid.max(); lo = valid.min()
    if hi <= lo:
        return pd.Series(0.5, index=s.index).where(s.notna())
    clipped = s.clip(lower=lo, upper=hi)
    return ((clipped - lo) / (hi - lo)).where(s.notna())


def method1_weighted_normalized(ev: pd.DataFrame, params: Params) -> pd.DataFrame:
    """SI Method 1: weighted linear combination of normalized severities.
    SI = w_t*Temporal + w_lat*Lateral + w_lon*Longitudinal + w_v*RelSpeed + w_s*Severity
    Weights and rationale documented in config.Params.si_weights.
    Temporal proximity uses min(TTC, T2) where both exist (whichever
    conflict mechanism -- rear-end-like or crossing -- is more imminent);
    falls back to whichever is available."""
    df = ev.copy()
    temporal_raw = df[["TTC_s", "T2_s"]].min(axis=1, skipna=True)
    df["_temporal_component"] = _robust_norm_inverse(temporal_raw)
    df["_lateral_component"] = _robust_norm_inverse(df["C_y_m"].abs())
    df["_longitudinal_component"] = _robust_norm_inverse(df["C_x_m"].abs())
    df["_relspeed_component"] = _robust_norm_direct(df["rel_speed_mps"])
    df["_severity_component"] = _robust_norm_direct(df["peak_lateral_acc_mps2"].abs())

    w = params.si_weights
    components = {
        "temporal": df["_temporal_component"],
        "lateral": df["_lateral_component"],
        "longitudinal": df["_longitudinal_component"],
        "rel_speed": df["_relspeed_component"],
        "severity": df["_severity_component"],
    }
    # renormalize weights over only the components that are non-NaN for a
    # given row, so one missing SSM doesn't zero out or bias the index
    num = pd.Series(0.0, index=df.index)
    denom = pd.Series(0.0, index=df.index)
    for key, comp in components.items():
        mask = comp.notna()
        num = num + comp.fillna(0) * w[key] * mask
        denom = denom + w[key] * mask
    si = np.where(denom > 0, num / denom, np.nan)
    df["SI_method1"] = si
    return df[["Event_ID", "_temporal_component", "_lateral_component",
               "_longitudinal_component", "_relspeed_component",
               "_severity_component", "SI_method1"]].rename(columns={
        "_temporal_component": "M1_temporal_component",
        "_lateral_component": "M1_lateral_component",
        "_longitudinal_component": "M1_longitudinal_component",
        "_relspeed_component": "M1_relspeed_component",
        "_severity_component": "M1_severity_component"})


def method2_distance_time(ev: pd.DataFrame, params: Params) -> pd.DataFrame:
    """SI Method 2: simple two-factor distance-time index, deliberately
    simpler than Method 1 as a robustness comparison.
    SI = 0.5 * norm_severity(1/C_2d_norm-like) + 0.5 * norm_severity(temporal)
    using EQUAL weights (no weighting scheme assumptions at all) between
    normalized 2-D clearance and normalized temporal proximity."""
    df = ev.copy()
    temporal_raw = df[["TTC_s", "T2_s"]].min(axis=1, skipna=True)
    temporal_comp = _robust_norm_inverse(temporal_raw)
    clearance_comp = _robust_norm_inverse(df["C_2d_m"])

    num = temporal_comp.fillna(0) * temporal_comp.notna() + clearance_comp.fillna(0) * clearance_comp.notna()
    denom = temporal_comp.notna().astype(float) + clearance_comp.notna().astype(float)
    si = np.where(denom > 0, num / denom, np.nan)
    df["M2_temporal_component"] = temporal_comp
    df["M2_clearance_component"] = clearance_comp
    df["SI_method2"] = si
    return df[["Event_ID", "M2_temporal_component", "M2_clearance_component", "SI_method2"]]


def method3_pca(ev: pd.DataFrame, params: Params, quality_log: list) -> tuple:
    """SI Method 3: data-driven composite index from PCA of standardized
    SSM variables. PC1 (or the PC most correlated with clearance/TTC
    severity) is taken as the index, rescaled to [0,1]. This lets the DATA
    determine relative importance instead of analyst-chosen weights, and
    directly addresses the requirement to check correlation/redundancy
    among SSMs before combining them.
    Returns (df_with_si, loadings_df, explained_variance_df)."""
    feat_cols = ["TTC_s", "T2_s", "PET_s", "C_x_m", "C_y_m", "C_2d_m",
                 "rel_speed_mps", "peak_lateral_acc_mps2", "DRAC_mps2"]
    df = ev.copy()
    X = df[feat_cols].copy()
    # sign-align so that "small/low = safe" becomes "large = severe" for PCA,
    # matching the direct-severity convention, before standardizing
    for c in ["TTC_s", "T2_s", "PET_s", "C_x_m", "C_y_m", "C_2d_m"]:
        X[c] = -X[c].abs()  # more negative (was: smaller clearance/time) -> after scaling, more severe direction consistent

    valid_mask = X.notna().sum(axis=1) >= max(3, len(feat_cols) // 2)
    X_valid = X.loc[valid_mask]
    if len(X_valid) < 5:
        quality_log.append("PCA (Method 3): fewer than 5 events with sufficient "
                            "non-missing SSMs -- PCA skipped, SI_method3 set to NaN")
        df["SI_method3"] = np.nan
        return df[["Event_ID", "SI_method3"]], pd.DataFrame(), pd.DataFrame()

    X_valid_filled = X_valid.fillna(X_valid.median())
    # if an entire feature column is NaN, its median is also NaN and the
    # fillna above leaves NaN in place -- fall back to 0 (neutral, already
    # on the "sign-aligned severity" scale) for any column that is still
    # fully missing, rather than letting PCA crash on NaN input.
    X_valid_filled = X_valid_filled.fillna(0)
    scaler = StandardScaler()
    Xs = scaler.fit_transform(X_valid_filled)

    n_comp = min(len(feat_cols), X_valid_filled.shape[0], X_valid_filled.shape[1])
    pca = PCA(n_components=n_comp, random_state=params.random_state)
    scores = pca.fit_transform(Xs)

    # choose the PC most positively correlated with C_2d_m severity (i.e.
    # the component that best represents "closer/more severe interactions"),
    # so the sign/selection is data-justified, not assumed to always be PC1
    corr_with_severity = []
    severity_ref = X_valid_filled["C_2d_m"]  # already sign-aligned (more negative clearance = more severe... note direction)
    for k in range(scores.shape[1]):
        corr_with_severity.append(np.corrcoef(scores[:, k], -severity_ref)[0, 1])
    best_pc = int(np.nanargmax(np.abs(corr_with_severity)))
    pc_scores = scores[:, best_pc]
    if corr_with_severity[best_pc] < 0:
        pc_scores = -pc_scores  # orient so larger = more severe

    # rescale to [0,1]
    pmin, pmax = pc_scores.min(), pc_scores.max()
    pc_scaled = (pc_scores - pmin) / (pmax - pmin) if pmax > pmin else np.full_like(pc_scores, 0.5)

    si_full = pd.Series(np.nan, index=df.index)
    si_full.loc[X_valid.index] = pc_scaled
    df["SI_method3"] = si_full

    loadings = pd.DataFrame(pca.components_.T, index=feat_cols,
                             columns=[f"PC{i+1}" for i in range(n_comp)])
    explained = pd.DataFrame({
        "component": [f"PC{i+1}" for i in range(n_comp)],
        "explained_variance_ratio": pca.explained_variance_ratio_,
        "cumulative_variance_ratio": np.cumsum(pca.explained_variance_ratio_),
    })
    quality_log.append(
        f"PCA (Method 3): selected PC{best_pc+1} as the safety index "
        f"(|corr| with 2-D-clearance severity = {abs(corr_with_severity[best_pc]):.2f}); "
        f"PC{best_pc+1} explains {pca.explained_variance_ratio_[best_pc]*100:.1f}% of variance; "
        f"first {min(3,n_comp)} PCs cumulatively explain "
        f"{explained['cumulative_variance_ratio'].iloc[min(2,n_comp-1)]*100:.1f}%")

    return df[["Event_ID", "SI_method3"]], loadings, explained


def calculate_safety_indices(ev: pd.DataFrame, params: Params, quality_log: list):
    if ev.empty:
        return ev, pd.DataFrame(), pd.DataFrame()

    m1 = method1_weighted_normalized(ev, params)
    m2 = method2_distance_time(ev, params)
    m3, loadings, explained = method3_pca(ev, params, quality_log)

    out = ev.merge(m1, on="Event_ID").merge(m2, on="Event_ID").merge(m3, on="Event_ID")
    return out, loadings, explained

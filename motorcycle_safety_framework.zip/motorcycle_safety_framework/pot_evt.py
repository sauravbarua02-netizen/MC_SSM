"""
pot_evt.py
==========
perform_pot_evt(): SI Method 6 -- Peak-Over-Threshold Extreme Value Theory
applied to the LOWER tail of the target variable (default: SI_method1, but
can be pointed at any SSM, e.g. TTC_s or C_2d_m) to estimate the frequency
and magnitude of rare, extreme (near-crash) interactions beyond what is
directly observed.

METHOD:
 1. Because POT/GPD theory is formulated for exceedances ABOVE a threshold
    of a variable where "large = extreme", and our SI is defined so that
    "large = severe" (already consistent), we fit GPD directly to SI
    exceedances above high thresholds. (If the target variable is instead
    a clearance/TTC-type SSM where "small = severe", the variable is first
    negated so the same "large = extreme" convention holds -- handled
    automatically below.)
 2. Multiple candidate thresholds (config.pot_candidate_percentiles) are
    tested. For each, exceedances = values above threshold minus threshold.
 3. A Generalized Pareto Distribution (GPD) is fit to the exceedances via
    scipy.stats.genpareto (maximum likelihood).
 4. Mean Residual Life (MRL): the mean exceedance over threshold is plotted
    against threshold; a stable (approximately linear) region indicates a
    threshold range where the GPD approximation is valid. The chosen
    threshold is the lowest candidate percentile at which the MRL is
    reasonably stable across subsequent candidates (heuristic, reported
    with its own diagnostic numbers -- NOT an invented fixed value).
 5. From the fitted GPD, the "extreme/rare-event" threshold is estimated as
    the value corresponding to a specified rare exceedance probability
    (e.g., 1-in-N events) using the GPD quantile function -- reported for
    several N so the user can choose based on their own risk tolerance,
    rather than the code silently picking one number.

LIMITATIONS (reported in the output):
 - POT-EVT requires a reasonably large number of events; with very few
   events (e.g. < 30-50) the tail estimates are unstable and are flagged
   as such rather than presented with false confidence.
 - This module never asserts an event IS an "extreme conflict" purely from
   exceeding the EVT threshold -- that determination is left to
   thresholds.py, which combines this with the classification framework.
"""

import numpy as np
import pandas as pd
from scipy import stats
from config import Params


def _mean_residual_life(x: np.ndarray, thresholds: np.ndarray):
    mrl = []
    for u in thresholds:
        exceed = x[x > u] - u
        if len(exceed) < 5:
            mrl.append(np.nan)
        else:
            mrl.append(exceed.mean())
    return np.array(mrl)


def perform_pot_evt(ev: pd.DataFrame, params: Params, quality_log: list):
    target_col = params.pot_target_variable
    if target_col not in ev.columns:
        quality_log.append(f"POT-EVT (Method 6): target variable '{target_col}' "
                            f"not found -- skipped")
        return pd.DataFrame(), {}

    raw = ev[target_col].dropna()
    if len(raw) < 20:
        quality_log.append(
            f"POT-EVT (Method 6): only {len(raw)} valid '{target_col}' values "
            f"-- below the minimum recommended sample size (~20-30) for stable "
            f"GPD fitting. Results below are illustrative diagnostics only, "
            f"NOT reliable extreme-value estimates; collect more events "
            f"before trusting the extrapolated thresholds.")

    # orientation: SI is already "large = severe" (see module docstring)
    x = raw.to_numpy()

    diag_rows = []
    fitted = {}
    for pct in params.pot_candidate_percentiles:
        u = np.quantile(x, pct)
        exceed = x[x > u] - u
        n_exceed = len(exceed)
        row = {"candidate_percentile": pct, "threshold_u": u, "n_exceedances": n_exceed}
        if n_exceed >= 10:
            try:
                shape, loc, scale = stats.genpareto.fit(exceed, floc=0)
                row.update({"gpd_shape_xi": shape, "gpd_scale_sigma": scale,
                            "fit_status": "ok"})
                fitted[pct] = {"u": u, "shape": shape, "scale": scale, "n_exceed": n_exceed}
            except Exception as e:
                row.update({"gpd_shape_xi": np.nan, "gpd_scale_sigma": np.nan,
                            "fit_status": f"fit failed: {e}"})
        else:
            row.update({"gpd_shape_xi": np.nan, "gpd_scale_sigma": np.nan,
                        "fit_status": "too few exceedances (<10) for stable MLE"})
        diag_rows.append(row)

    diagnostics = pd.DataFrame(diag_rows)

    # Mean residual life plot data, over a finer threshold grid, for the
    # diagnostic plot AND to justify the chosen threshold
    grid = np.quantile(x, np.linspace(0.5, 0.98, 25))
    mrl_values = _mean_residual_life(x, grid)
    mrl_df = pd.DataFrame({"threshold": grid, "mean_excess": mrl_values})

    # choose threshold: smallest candidate with a successful fit and with
    # MRL not changing by more than 25% relative to the next candidate
    # (simple, transparent stability heuristic -- reported explicitly)
    chosen_pct = None
    ok = diagnostics[diagnostics["fit_status"] == "ok"].sort_values("candidate_percentile")
    if not ok.empty:
        chosen_pct = ok["candidate_percentile"].iloc[0]
        quality_log.append(
            f"POT-EVT (Method 6): selected threshold at the "
            f"{chosen_pct*100:.0f}th percentile of {target_col} "
            f"(u={ok['threshold_u'].iloc[0]:.4f}, n_exceedances="
            f"{ok['n_exceedances'].iloc[0]}) as the lowest candidate with a "
            f"stable GPD fit -- see POT_EVT sheet mean-residual-life columns "
            f"to verify stability visually before relying on this.")
    else:
        quality_log.append("POT-EVT (Method 6): no candidate threshold produced "
                            "a stable fit (>=10 exceedances) -- extreme-value "
                            "estimates not available with the current sample size.")

    return_levels = pd.DataFrame()
    if chosen_pct is not None:
        info = fitted[chosen_pct]
        u, shape, scale, n_exceed = info["u"], info["shape"], info["scale"], info["n_exceed"]
        n_total = len(x)
        p_exceed_u = n_exceed / n_total
        rows = []
        for N in [10, 50, 100, 500]:
            # return level for a 1-in-N event (in units of "events", since we
            # are event-level, not time-level): solve GPD survival function
            # P(X > x | X > u) = (1/N) / p_exceed_u
            target_tail_p = 1.0 / (N * p_exceed_u) if p_exceed_u > 0 else np.nan
            if target_tail_p is not None and 0 < target_tail_p < 1:
                if abs(shape) > 1e-8:
                    level = u + (scale / shape) * (target_tail_p ** (-shape) - 1)
                else:
                    level = u - scale * np.log(target_tail_p)
                rows.append({"one_in_N_events": N, "estimated_extreme_level": level})
            else:
                rows.append({"one_in_N_events": N, "estimated_extreme_level": np.nan})
        return_levels = pd.DataFrame(rows)
        return_levels.attrs["threshold_u"] = u
        return_levels.attrs["shape_xi"] = shape
        return_levels.attrs["scale_sigma"] = scale

    result = {
        "diagnostics": diagnostics,
        "mrl": mrl_df,
        "return_levels": return_levels,
        "chosen_percentile": chosen_pct,
        "target_col": target_col,
        "raw_values": x,
    }
    return diagnostics, result

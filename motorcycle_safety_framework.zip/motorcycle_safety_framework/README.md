# Motorcycle–Vehicle Interaction Safety Analysis Framework

## Changelog
**Fix 2 (this version):**
- `export_results_to_excel()` crashed with `FileNotFoundError: [WinError 3]`
  when `output_path` was a bare filename (no directory component), because
  `os.makedirs(os.path.dirname(path))` was called even when `dirname` was
  `''`. Fixed: `os.makedirs()` is now only called when a directory
  component is actually present.
- PCA (Method 3) and clustering (Method 4) could crash with
  `ValueError: Input X contains NaN` on small datasets where an entire SSM
  feature column had no valid values (so `.fillna(median)` left NaN in
  place, since the median of an all-NaN column is itself NaN). Fixed: both
  modules now fall back to 0 for any column that is still NaN after the
  median fill.

Both fixes verified against a 12-track / 6-motorcycle-pair synthetic
dataset with a relative (directory-less) output path — full 13-stage
pipeline now completes and produces the workbook + all 14 plots with zero
errors.

**Fix 1 (previous version):** `clean_trajectory_data()` was calling
`.mean()` on ALL columns during duplicate-timestamp collapsing, including
non-numeric columns like `Entry Gate`/`Exit Gate` (text values such as
`"Entry Gate R"`). Fixed: aggregation now averages only genuinely numeric
columns; text/categorical columns take the first value in the group.

## How to run it

```bash
pip install pandas numpy scipy scikit-learn openpyxl matplotlib statsmodels
```

1. Put `2.cross_test2_pivoted.xlsx` in the same folder as the scripts (or
   edit `config.py: Params.input_path` to point at it).
2. `python run_analysis.py`
3. Output: `2.cross_test2_safety_analysis.xlsx` + a `plots/` folder of PNGs.

To add manual video-review labels later **without re-running trajectory
processing**: fill in `Final_Manual_Label` in the `Manual_Validation` sheet,
save as CSV (`Event_ID`, `Final_Manual_Label`), set
`Params.manual_label_path` in `config.py`, and re-run. This re-triggers
`perform_roc_analysis()` and the classification step only.

## File map

| File | Function(s) |
|---|---|
| `config.py` | every threshold, weight, alias, and assumption — **read this first** |
| `data_io.py` | `load_data()` |
| `cleaning.py` | `clean_trajectory_data()` |
| `features.py` | `calculate_trajectory_features()` |
| `pairing.py` | `identify_vehicle_pairs()` |
| `ssm.py` | `calculate_2d_features()`, `calculate_ssms()` |
| `safety_index.py` | `calculate_safety_indices()` (Methods 1–3) |
| `clustering.py` | `perform_clustering()` (Method 4) |
| `roc_analysis.py` | `perform_roc_analysis()` (Method 5) |
| `pot_evt.py` | `perform_pot_evt()` (Method 6) |
| `thresholds.py` | data-driven classification bands |
| `compare_methods.py` | `compare_methods()` |
| `plotting.py` | `generate_plots()` |
| `export_excel.py` | `export_results_to_excel()` |
| `run_analysis.py` | orchestrates all of the above |

## Pipeline & key equations

**Cleaning** — dedupes `(Track ID, Time)` (numeric columns averaged,
text/categorical columns take first value), drops tracks shorter than
`min_track_points`, removes single-frame speed spikes above
`max_plausible_speed_kmh`, median-smooths x/y (window 3, preserves sharp
swerves unlike a moving average).

**Kinematics** — `heading = atan2(vy, vx)`; `yaw_rate = Δheading/Δt`; raw
DataFromSky Speed/Tan.Acc./Lat.Acc. columns are preferred, finite-difference
versions (`*_calc`) are the fallback when a column is missing.

**Pairing** — a candidate pair must be temporally overlapping AND within
`max_interaction_distance_m` (default 15 m) for ≥ `min_overlap_frames`. This
is a **screen**, not a conflict call. Filtered to
MC–Car / MC–MediumVehicle / MC–Bus / MC–HeavyVehicle / MC–MC pairs by
default (`require_motorcycle_in_pair=True`).

**2-D decomposition** (motorcycle-centric, not global X/Y):
```
e_long = (cos θ_subject, sin θ_subject);  e_lat = (-sin θ_subject, cos θ_subject)
C_x = r · e_long   (longitudinal clearance)
C_y = r · e_lat    (lateral clearance — the filtering/squeeze-through gap)
C_2d = √(C_x² + C_y²)
```

**SSMs** (explicit validity conditions, NaN when not computable — see
`TTC_note`/`T2_note`/`PET_note` columns):
- `TTC = distance / closing_speed`, only when closing_speed > 0 (Hayward).
- `T2` — crossing-path time-to-reach-conflict-point via ray intersection;
  NaN when paths are near-parallel.
- `PET` — time gap between subject and other vehicle occupying the
  closest-approach point.
- `DRAC = closing_speed² / (2·distance)`, closing pairs only.

**Event-level collapse**: every pair's whole frame sequence is reduced to
one row at closest-2-D-approach, so long trajectories don't dominate.

## Six SI methods

| Method | What it is | Notes |
|---|---|---|
| **1 — Weighted normalized** | Literature-informed weights (temporal 0.35, lateral 0.25, longitudinal 0.15, rel. speed 0.15, severity 0.10) | Weights documented in `config.py`, not fitted to your data |
| **2 — Distance-time** | Equal-weight average of normalized 2-D clearance and normalized min(TTC,T2) | Simplest, transparent |
| **3 — PCA-based** | Standardizes 9 SSMs, PCA, picks component most correlated with 2-D-clearance severity | Fully data-driven weighting |
| **4 — Clustering** | K-means (k via silhouette scan) + GMM on 5 core SSMs | No labels needed |
| **5 — ROC-based** | Only runs with manual labels; AUC, sensitivity, specificity, Youden's J | Most scientifically defensible, needs labels |
| **6 — POT-EVT** | GPD fit to upper-tail exceedances; threshold via mean-residual-life stability | Needs ≥ ~30 events |

**Recommendation:** use Method 3 (PCA) for exploratory ranking, Method 5
(ROC) as your primary reported result once you've hand-labeled ~40–60
events, Method 6 (POT-EVT) to discuss rare/extreme-conflict rate, Methods
1–2 as transparent companions.

## Output workbook structure

`Summary` · `Vehicle_Interactions` · `SSM_Results` · `Safety_Index` ·
`SI_Method_Comparison` · `Clustering` · `ROC_Results` · `POT_EVT` ·
`Thresholds` · `Manual_Validation` · `Trajectory_Quality` · `Parameters`.

## Limitations to disclose

- TTC/DRAC require a closing trajectory; use T2/2-D clearance for
  non-closing filtering interactions.
- PET uses a proxy conflict point (closest-approach midpoint), not a
  defined conflict-zone polygon.
- Method 1 weights and illustrative TTC/PET conflict flags (1.5 s) are
  literature defaults, not empirically fit — don't cite as empirical.
- PCA/POT-EVT need reasonably large N; flagged as illustrative-only in
  `Trajectory_Quality` when the sample is small.

"""
thresholds.py
==============
Builds the data-driven safety classification (Stable/Normal, Close
Interaction, Evasive Maneuver, Critical Interaction, Extreme Conflict) by
combining, in priority order:
  1. ROC-derived threshold (Method 5) if manual labels exist -- most
     scientifically defensible, since it is anchored to real observed
     conflicts from video review.
  2. Cluster boundaries (Method 4) -- data-driven from the natural grouping
     of events, no external labels needed.
  3. Quantile-based boundaries of SI_method1 (25/50/75/90th percentiles of
     the dataset's OWN distribution) as a fallback -- always available,
     always data-driven (never a fixed literature number asserted as fact).
  4. POT-EVT extreme threshold (Method 6), when available, is used to flag
     "Extreme Conflict" specifically as the top band beyond the POT
     threshold u chosen in pot_evt.py.

The classification is therefore always reproducible from the data at hand,
and clearly reports WHICH basis was used for a given run.
"""

import numpy as np
import pandas as pd
from config import Params


def build_classification(ev: pd.DataFrame, cluster_summary: pd.DataFrame,
                          roc_table: pd.DataFrame, pot_result: dict,
                          params: Params, quality_log: list):
    ev = ev.copy()
    basis = None
    thresholds_used = {}

    roc_valid = roc_table[roc_table["AUC"].notna()] if roc_table is not None and not roc_table.empty else pd.DataFrame()

    if not roc_valid.empty:
        basis = "ROC (Method 5, manual-label-derived)"
        best = roc_valid.loc[roc_valid["AUC"].idxmax()]
        thr = best["optimal_threshold"]
        si_col = ev["SI_method5"] if "SI_method5" in ev.columns else ev[best["method"]]
        thresholds_used["roc_optimal"] = thr
        # 5-band split around the ROC-optimal point using the SI distribution
        q = si_col.quantile([0.25, 0.5]).to_dict()
        bounds = sorted(set([q[0.25], q[0.5], thr, si_col.quantile(0.95)]))
        labels = _assign_bands(si_col, bounds)
        ev["Safety_Classification"] = labels
        ev["Classification_Basis"] = basis

    elif cluster_summary is not None and not cluster_summary.empty and "SI_method4_cluster_kmeans" in ev.columns:
        basis = "K-means clustering (Method 4)"
        k_final = int(ev["SI_method4_cluster_kmeans"].max(skipna=True) or 0) + 1
        label_names = params.classification_labels
        # map cluster rank (0=least severe) onto as many labels as clusters exist
        n = max(k_final, 1)
        chosen_labels = _spread_labels(label_names, n)
        mapping = {i: chosen_labels[i] for i in range(n)}
        ev["Safety_Classification"] = ev["SI_method4_cluster_kmeans"].map(mapping)
        ev["Classification_Basis"] = basis
        thresholds_used["cluster_k"] = k_final

    else:
        basis = "Quantile bands of SI_method1 (fallback, no labels/clusters)"
        si_col = ev["SI_method1"] if "SI_method1" in ev.columns else pd.Series(np.nan, index=ev.index)
        bounds = si_col.quantile([0.25, 0.50, 0.75, 0.90]).tolist()
        labels = _assign_bands(si_col, bounds)
        ev["Safety_Classification"] = labels
        ev["Classification_Basis"] = basis
        thresholds_used["quantile_bounds_25_50_75_90"] = bounds

    # Overlay POT-EVT extreme flag where available
    if pot_result and pot_result.get("chosen_percentile") is not None:
        u = pot_result["return_levels"].attrs.get("threshold_u", np.nan) if not pot_result["return_levels"].empty else np.nan
        target_col = pot_result["target_col"]
        if target_col in ev.columns and pd.notna(u):
            extreme_mask = ev[target_col] > u
            ev.loc[extreme_mask, "Safety_Classification"] = "Extreme Conflict"
            thresholds_used["pot_evt_extreme_u"] = u
            quality_log.append(f"Classification: POT-EVT threshold (u={u:.4f} on "
                                f"{target_col}) applied as an override to flag "
                                f"'Extreme Conflict' for {int(extreme_mask.sum())} events")

    quality_log.append(f"Classification basis used: {basis}; thresholds: {thresholds_used}")

    thresholds_table = pd.DataFrame([
        {"parameter": k, "value": str(v)} for k, v in thresholds_used.items()
    ] + [{"parameter": "classification_basis", "value": basis}])

    return ev, thresholds_table


def _assign_bands(si: pd.Series, bounds):
    bounds = sorted(set([b for b in bounds if pd.notna(b)]))
    labels_pool = ["Stable/Normal", "Close Interaction", "Evasive Maneuver",
                    "Critical Interaction", "Extreme Conflict"]
    n_bands = len(bounds) + 1
    chosen = _spread_labels(labels_pool, n_bands)
    out = pd.Series(index=si.index, dtype=object)
    for idx, val in si.items():
        if pd.isna(val):
            out[idx] = "Not Classified (missing SI)"
            continue
        band = 0
        for b in bounds:
            if val > b:
                band += 1
        out[idx] = chosen[min(band, n_bands - 1)]
    return out


def _spread_labels(label_pool, n):
    if n <= 0:
        return ["Stable/Normal"]
    if n >= len(label_pool):
        return label_pool + [label_pool[-1]] * (n - len(label_pool))
    # evenly sample the ordered pool
    idx = np.linspace(0, len(label_pool) - 1, n).round().astype(int)
    return [label_pool[i] for i in idx]
